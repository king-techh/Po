#!/bin/bash
# ═══════════════════════════════════════════════════
# ToxicPay - Startup Script with Cloudflare Tunnel
# Toxic Tech Kenya - M-Pesa Payment Gateway
# ═══════════════════════════════════════════════════

set -e

echo ""
echo "═══════════════════════════════════════════════"
echo "  TOXICPAY - Starting Deployment"
echo "  Toxic Tech Kenya"
echo "═══════════════════════════════════════════════"
echo ""

# Step 1: Install dependencies if needed
if [ ! -d "node_modules" ]; then
  echo "[1/5] Installing dependencies..."
  npm install --production 2>/dev/null || npm install 2>/dev/null
  echo "  Dependencies installed"
else
  echo "[1/5] Dependencies already installed, skipping"
fi

# Step 2: Generate Prisma client
echo "[2/5] Generating Prisma client..."
npx prisma generate --no-hints 2>/dev/null || true
echo "  Done"

# Step 3: Push database schema
echo "[3/5] Syncing database schema..."
npx prisma db push --accept-data-loss 2>/dev/null || true
echo "  Done"

# Step 4: Start the server
PORT=${PORT:-3000}
HOSTNAME=${HOSTNAME:-0.0.0.0}
echo "[4/5] Starting ToxicPay on port ${PORT}..."
node index.js &
SERVER_PID=$!
echo "  Server PID: $SERVER_PID"

# Wait for server to be ready
echo "  Waiting for server..."
for i in $(seq 1 30); do
  if curl -sf http://localhost:${PORT} > /dev/null 2>&1; then
    echo "  Server is ready!"
    break
  fi
  sleep 1
done

# Step 5: Start Cloudflare Tunnel
echo "[5/5] Starting Cloudflare Tunnel..."
if [ -n "$CLOUDFLARE_TUNNEL_TOKEN" ]; then
  if command -v cloudflared &> /dev/null; then
    cloudflared tunnel run --token "$CLOUDFLARE_TUNNEL_TOKEN" &
    TUNNEL_PID=$!
    echo "  Cloudflare Tunnel PID: $TUNNEL_PID"
  else
    echo "  Installing cloudflared..."
    curl -L https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64 -o /usr/local/bin/cloudflared
    chmod +x /usr/local/bin/cloudflared
    cloudflared tunnel run --token "$CLOUDFLARE_TUNNEL_TOKEN" &
    TUNNEL_PID=$!
    echo "  Cloudflare Tunnel PID: $TUNNEL_PID"
  fi
else
  echo "  No CLOUDFLARE_TUNNEL_TOKEN set. Skipping tunnel."
fi

echo ""
echo "═══════════════════════════════════════════════"
echo "  TOXICPAY IS RUNNING!"
echo "  Local:  http://localhost:${PORT}"
echo "  Remote: Via Cloudflare Tunnel"
echo "═══════════════════════════════════════════════"
echo ""

# Keep running and handle shutdown
trap "echo 'Shutting down...'; kill $SERVER_PID 2>/dev/null; kill $TUNNEL_PID 2>/dev/null; exit 0" SIGTERM SIGINT
wait
