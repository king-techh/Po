import { NextRequest, NextResponse } from 'next/server';
import { getPlatformSettings, updatePlatformSettings } from '@/lib/payengine';

/**
 * GET - Get platform settings
 */
export async function GET() {
  try {
    const settings = await getPlatformSettings();
    return NextResponse.json({
      settings: {
        id: settings.id,
        businessName: settings.businessName,
        shortcode: settings.shortcode,
        passkey: settings.passkey,
        consumerKey: settings.consumerKey || '',
        consumerSecret: settings.consumerSecret || '',
        environment: settings.environment,
        channelType: settings.channelType || 'paybill',
        callbackBase: settings.callbackBase || '',
        serviceFeePct: settings.serviceFeePct,
        minServiceFee: settings.minServiceFee,
        isConfigured: settings.isConfigured,
      },
    });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'Failed to get settings';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

/**
 * POST - Update platform settings
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { businessName, shortcode, passkey, consumerKey, consumerSecret, environment, channelType, callbackBase } = body;

    const settings = await updatePlatformSettings({
      businessName,
      shortcode,
      passkey,
      consumerKey: consumerKey || undefined,
      consumerSecret: consumerSecret || undefined,
      environment,
      channelType,
      callbackBase,
    });

    return NextResponse.json({
      success: true,
      isConfigured: settings.isConfigured,
      message: settings.isConfigured
        ? 'Daraja credentials saved! Real STK Push will now work.'
        : 'Settings saved. Add Consumer Key/Secret to connect Daraja for real STK Push.',
    });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'Failed to save settings';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
