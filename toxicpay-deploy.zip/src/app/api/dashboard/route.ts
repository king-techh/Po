import { NextRequest, NextResponse } from 'next/server';
import { getMerchantDashboard, getPlatformSettings } from '@/lib/payengine';
import { db } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const merchantId = request.headers.get('x-merchant-id');
    if (!merchantId) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const [stats, platformConfig] = await Promise.all([
      getMerchantDashboard(merchantId),
      getPlatformSettings(),
    ]);

    const recentTransactions = await db.transaction.findMany({
      where: { merchantId },
      orderBy: { createdAt: 'desc' },
      take: 20,
    });

    const apiKeys = await db.apiKey.findMany({
      where: { merchantId, active: true, revokedAt: null },
      select: { id: true, name: true, key: true, secret: true, environment: true, active: true, lastUsedAt: true },
    });

    return NextResponse.json({
      stats,
      recentTransactions,
      apiKeys,
      platformConfig: {
        id: platformConfig.id,
        businessName: platformConfig.businessName,
        shortcode: platformConfig.shortcode,
        passkey: platformConfig.passkey,
        consumerKey: platformConfig.consumerKey || '',
        consumerSecret: platformConfig.consumerSecret || '',
        environment: platformConfig.environment,
        callbackBase: platformConfig.callbackBase || '',
        serviceFeePct: platformConfig.serviceFeePct,
        minServiceFee: platformConfig.minServiceFee,
        isConfigured: platformConfig.isConfigured,
      },
    });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'Dashboard fetch failed';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
