import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { generateApiKey, generateApiSecret, generateSandboxKey } from '@/lib/payengine';

export async function GET(request: NextRequest) {
  try {
    const merchantId = request.headers.get('x-merchant-id');
    if (!merchantId) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const keys = await db.apiKey.findMany({
      where: { merchantId },
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json({ keys });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'Failed to fetch API keys';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const merchantId = request.headers.get('x-merchant-id');
    if (!merchantId) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const { name, environment } = body;

    if (!name) {
      return NextResponse.json({ error: 'Key name is required' }, { status: 400 });
    }

    const isSandbox = environment === 'sandbox';

    const apiKey = await db.apiKey.create({
      data: {
        merchantId,
        name,
        key: isSandbox ? generateSandboxKey() : generateApiKey(),
        secret: generateApiSecret(),
        environment: environment || 'sandbox',
      },
    });

    return NextResponse.json({
      success: true,
      key: {
        id: apiKey.id,
        name: apiKey.name,
        key: apiKey.key,
        secret: apiKey.secret,
        environment: apiKey.environment,
        active: apiKey.active,
      },
    });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'Failed to create API key';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const merchantId = request.headers.get('x-merchant-id');
    if (!merchantId) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const keyId = searchParams.get('id');

    if (!keyId) {
      return NextResponse.json({ error: 'API key ID required' }, { status: 400 });
    }

    await db.apiKey.update({
      where: { id: keyId },
      data: { active: false, revokedAt: new Date() },
    });

    return NextResponse.json({ success: true, message: 'API key revoked' });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'Failed to revoke API key';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
