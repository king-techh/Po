import { NextResponse } from 'next/server';

export async function GET() {
  return NextResponse.json({
    service: 'ToxicPay',
    version: '1.0.0',
    status: 'OPERATIONAL',
    mpesa_connectivity: 'ACTIVE',
    timestamp: new Date().toISOString(),
    endpoints: {
      stk_initiate: '/api/v1/stk/initiate',
      stk_query: '/api/v1/stk/query',
      transactions: '/api/v1/transactions',
      fees: '/api/v1/fees',
      service_status: '/api/v1/service-status',
    },
  });
}
