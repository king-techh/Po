import { NextRequest, NextResponse } from 'next/server';
import { completeTransaction } from '@/lib/payengine';

/**
 * M-Pesa Callback Endpoint
 * This is where Safaricom sends the STK Push result
 * When you configure Daraja, set this as your callback URL:
 * https://yourdomain.com/api/v1/callback
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();

    console.log('📱 M-Pesa Callback received:', JSON.stringify(body, null, 2));

    const { Body } = body;
    if (!Body || !Body.stkCallback) {
      return NextResponse.json({ error: 'Invalid callback format' }, { status: 400 });
    }

    const { MerchantRequestID, CheckoutRequestID, ResultCode, ResultDesc, CallbackMetadata } = Body.stkCallback;

    const { db } = await import('@/lib/db');
    const transaction = await db.transaction.findFirst({
      where: { checkoutRequestId: CheckoutRequestID },
    });

    if (!transaction) {
      console.error('Transaction not found for CheckoutRequestID:', CheckoutRequestID);
      return NextResponse.json({ error: 'Transaction not found' }, { status: 404 });
    }

    const isSuccess = ResultCode === '0';
    let mpesaReceipt = '';

    if (isSuccess && CallbackMetadata?.Item) {
      const receiptItem = CallbackMetadata.Item.find((i: any) => i.Name === 'MpesaReceiptNumber');
      mpesaReceipt = receiptItem?.Value || '';
    }

    await completeTransaction(
      transaction.id,
      isSuccess,
      mpesaReceipt,
      String(ResultCode),
      ResultDesc,
      JSON.stringify(Body)
    );

    return NextResponse.json({ received: true });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'Callback processing failed';
    console.error('Callback error:', message);
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
