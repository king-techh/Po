import { NextResponse } from 'next/server';

export async function GET() {
  return NextResponse.json({
    success: true,
    fees: {
      c2b_stk_push: {
        percentage: 1.5,
        minimum: 5,
        currency: 'KES',
        description: '1.5% per successful transaction, minimum KES 5',
        note: 'No charge for failed transactions',
      },
      b2c: {
        percentage: 1.0,
        minimum: 5,
        currency: 'KES',
        description: '1.0% per successful B2C payment, minimum KES 5',
      },
      reversal: {
        fixed: 0,
        currency: 'KES',
        description: 'Free - no charge for reversals',
      },
    },
    setup_fee: 0,
    monthly_fee: 0,
    pricing_model: 'pay_per_successful_transaction',
  });
}
