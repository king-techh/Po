import { NextRequest, NextResponse } from 'next/server';
import { authenticateApiKey } from '@/lib/payengine';
import { db } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const authHeader = request.headers.get('Authorization');
    const apiKey = authHeader?.replace('Bearer ', '') || request.headers.get('x-api-key');

    if (!apiKey) {
      return NextResponse.json({ error: 'API key required' }, { status: 401 });
    }

    const auth = await authenticateApiKey(apiKey);
    if (!auth) {
      return NextResponse.json({ error: 'Invalid or revoked API key' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status');
    const limit = parseInt(searchParams.get('limit') || '50');
    const offset = parseInt(searchParams.get('offset') || '0');

    const where: any = { merchantId: auth.merchantId };
    if (status) where.status = status;

    const [transactions, total] = await Promise.all([
      db.transaction.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        take: limit,
        skip: offset,
      }),
      db.transaction.count({ where }),
    ]);

    return NextResponse.json({
      success: true,
      total,
      limit,
      offset,
      transactions: transactions.map(t => ({
        id: t.id,
        external_reference: t.externalReference,
        transaction_type: t.transactionType,
        amount: t.amount,
        phone: t.phone,
        account_reference: t.accountReference,
        status: t.status.toUpperCase(),
        mpesa_receipt: t.mpesaReceipt,
        service_fee: t.serviceFee,
        channel_type: t.channelType,
        callback_delivered: t.callbackDelivered,
        created_at: t.createdAt,
        completed_at: t.completedAt,
      })),
    });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'Failed to fetch transactions';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
