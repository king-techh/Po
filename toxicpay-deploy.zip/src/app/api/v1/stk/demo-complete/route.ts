import { NextRequest, NextResponse } from 'next/server';
import { completeDemoTransaction } from '@/lib/payengine';

/**
 * Complete a demo transaction (simulated M-Pesa payment)
 * Called when the user enters PIN on the phone mockup
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { transaction_id, success } = body;

    if (!transaction_id) {
      return NextResponse.json({ error: 'transaction_id is required' }, { status: 400 });
    }

    await completeDemoTransaction(transaction_id, success !== false);

    return NextResponse.json({
      success: true,
      message: success !== false ? 'Demo payment completed' : 'Demo payment cancelled',
    });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'Demo completion failed';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
