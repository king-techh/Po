import { NextRequest, NextResponse } from 'next/server';
import { authenticateApiKey, initiateSTKPush, formatPhone } from '@/lib/payengine';

export async function POST(request: NextRequest) {
  try {
    const authHeader = request.headers.get('Authorization');
    const apiKey = authHeader?.replace('Bearer ', '') || request.headers.get('x-api-key');

    if (!apiKey) {
      return NextResponse.json({ error: 'API key required. Use Authorization: Bearer YOUR_KEY' }, { status: 401 });
    }

    const auth = await authenticateApiKey(apiKey);
    if (!auth) {
      return NextResponse.json({ error: 'Invalid or revoked API key' }, { status: 401 });
    }

    const body = await request.json();
    const { phone, amount, external_reference, callback_url, customer_name } = body;

    if (!phone) return NextResponse.json({ error: 'phone is required' }, { status: 400 });
    if (!amount || amount < 1) return NextResponse.json({ error: 'amount must be at least KES 1' }, { status: 400 });

    const formatted = formatPhone(phone);
    if (!/^254[0-9]{9}$/.test(formatted)) {
      return NextResponse.json({ error: 'Invalid phone number. Use 07XXXXXXXX, 7XXXXXXXX, or 254XXXXXXXXX' }, { status: 400 });
    }

    const isSandbox = auth.environment === 'sandbox';

    const result = await initiateSTKPush(auth.merchantId, {
      phone: formatted,
      amount: Math.round(amount),
      externalReference: external_reference,
      callbackUrl: callback_url,
      customerName: customer_name,
    }, isSandbox);

    return NextResponse.json(result);
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'STK Push initiation failed';
    console.error('❌ STK Push error:', message);
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
