import { NextRequest, NextResponse } from 'next/server';
import { authenticateApiKey, queryTransaction } from '@/lib/payengine';
import { db } from '@/lib/db';

export async function POST(request: NextRequest) {
  try {
    const authHeader = request.headers.get('Authorization');
    const apiKey = authHeader?.replace('Bearer ', '') || request.headers.get('x-api-key');

    if (!apiKey) return NextResponse.json({ error: 'API key required' }, { status: 401 });

    const auth = await authenticateApiKey(apiKey);
    if (!auth) return NextResponse.json({ error: 'Invalid or revoked API key' }, { status: 401 });

    const body = await request.json();
    const { checkout_request_id } = body;

    if (!checkout_request_id) return NextResponse.json({ error: 'checkout_request_id is required' }, { status: 400 });

    const isSandbox = auth.environment === 'sandbox';

    try {
      const result = await queryTransaction(auth.merchantId, checkout_request_id, isSandbox);

      const transaction = await db.transaction.findFirst({
        where: { checkoutRequestId: checkout_request_id, merchantId: auth.merchantId },
      });

      return NextResponse.json({
        success: true,
        transaction_id: transaction?.id,
        checkout_request_id,
        status: result.status,
        amount: transaction?.amount,
        phone: transaction?.phone,
        mpesa_receipt: transaction?.mpesaReceipt || result.mpesaReceipt,
        result_code: result.resultCode,
        result_desc: result.resultDesc,
        is_demo: result.isDemo,
      });
    } catch {
      // Fallback to DB
    }

    const transaction = await db.transaction.findFirst({
      where: { checkoutRequestId: checkout_request_id, merchantId: auth.merchantId },
    });

    if (!transaction) return NextResponse.json({ error: 'Transaction not found' }, { status: 404 });

    return NextResponse.json({
      success: true,
      transaction_id: transaction.id,
      checkout_request_id,
      status: transaction.status.toUpperCase(),
      amount: transaction.amount,
      phone: transaction.phone,
      mpesa_receipt: transaction.mpesaReceipt,
      result_code: transaction.mpesaResultCode,
      result_desc: transaction.mpesaResultDesc,
      is_demo: transaction.isDemo,
    });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'Query failed';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
