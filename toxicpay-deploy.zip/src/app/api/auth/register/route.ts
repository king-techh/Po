import { NextRequest, NextResponse } from 'next/server';
import { hashPassword, generateApiKey, generateApiSecret, generateSandboxKey } from '@/lib/payengine';
import { db } from '@/lib/db';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { businessName, email, phone, password } = body;

    if (!businessName || !email || !phone || !password) {
      return NextResponse.json({ error: 'All fields are required' }, { status: 400 });
    }

    const existing = await db.merchant.findUnique({ where: { email } });
    if (existing) {
      return NextResponse.json({ error: 'An account with this email already exists' }, { status: 409 });
    }

    const merchant = await db.merchant.create({
      data: {
        businessName,
        email,
        phone,
        password: hashPassword(password),
        serviceWallet: 1000,
      },
    });

    const sandboxKey = await db.apiKey.create({
      data: {
        merchantId: merchant.id,
        name: 'Sandbox Key',
        key: generateSandboxKey(),
        secret: generateApiSecret(),
        environment: 'sandbox',
      },
    });

    const liveKey = await db.apiKey.create({
      data: {
        merchantId: merchant.id,
        name: 'Live Key',
        key: generateApiKey(),
        secret: generateApiSecret(),
        environment: 'live',
      },
    });

    // Ensure platform settings exist
    const { getPlatformSettings } = await import('@/lib/payengine');
    await getPlatformSettings();

    await db.activityLog.create({
      data: {
        merchantId: merchant.id,
        action: 'account_created',
        details: `Account created for ${businessName}`,
      },
    });

    return NextResponse.json({
      success: true,
      message: 'Account created!',
      merchant: {
        id: merchant.id,
        businessName: merchant.businessName,
        email: merchant.email,
        phone: merchant.phone,
      },
      apiKeys: {
        sandbox: { key: sandboxKey.key, secret: sandboxKey.secret },
        live: { key: liveKey.key, secret: liveKey.secret },
      },
    });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'Registration failed';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
