import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const merchantId = request.headers.get('x-merchant-id');
    if (!merchantId) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const merchant = await db.merchant.findUnique({
      where: { id: merchantId },
      select: {
        id: true,
        businessName: true,
        email: true,
        phone: true,
        serviceWallet: true,
        kycVerified: true,
        callbackUrl: true,
        website: true,
        logo: true,
        defaultChannel: true,
        createdAt: true,
      },
    });

    if (!merchant) {
      return NextResponse.json({ error: 'Merchant not found' }, { status: 404 });
    }

    return NextResponse.json({ merchant });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'Failed to fetch merchant';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
