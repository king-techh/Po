import { NextRequest, NextResponse } from 'next/server';
import { hashPassword } from '@/lib/payengine';
import { db } from '@/lib/db';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { email, password } = body;

    if (!email || !password) {
      return NextResponse.json(
        { error: 'Email and password are required' },
        { status: 400 }
      );
    }

    const merchant = await db.merchant.findUnique({ where: { email } });

    if (!merchant || merchant.password !== hashPassword(password)) {
      return NextResponse.json(
        { error: 'Invalid email or password' },
        { status: 401 }
      );
    }

    if (!merchant.active) {
      return NextResponse.json(
        { error: 'Account is deactivated. Contact support.' },
        { status: 403 }
      );
    }

    // Get API keys
    const apiKeys = await db.apiKey.findMany({
      where: { merchantId: merchant.id, active: true, revokedAt: null },
    });

    return NextResponse.json({
      success: true,
      merchant: {
        id: merchant.id,
        businessName: merchant.businessName,
        email: merchant.email,
        phone: merchant.phone,
        serviceWallet: merchant.serviceWallet,
        kycVerified: merchant.kycVerified,
        callbackUrl: merchant.callbackUrl,
      },
      apiKeys: apiKeys.map(k => ({
        id: k.id,
        name: k.name,
        key: k.key,
        secret: k.secret,
        environment: k.environment,
        active: k.active,
      })),
    });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'Login failed';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
