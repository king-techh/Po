'use client';

import { useState, useEffect, useCallback } from 'react';
import {
  Phone, Zap, Shield, Key, Activity, DollarSign,
  ArrowRight, CheckCircle2, XCircle, Clock, Loader2,
  Eye, EyeOff, Copy, Plus, Trash2, RefreshCw, BarChart3,
  Settings, BookOpen, CreditCard, Globe, AlertCircle,
  Menu, X, LogOut, Wallet, TrendingUp, Users, Server,
  Save, Info, ExternalLink, Smartphone,
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Textarea } from '@/components/ui/textarea';

// ─── Types ───
type View = 'landing' | 'login' | 'register' | 'dashboard' | 'transactions' | 'api-keys' | 'platform-settings' | 'docs' | 'stk-push';
type STKStatus = 'idle' | 'initiating' | 'pending' | 'success' | 'failed' | 'timeout';

interface MerchantData {
  id: string;
  businessName: string;
  email: string;
  phone: string;
  serviceWallet: number;
  callbackUrl?: string;
}

interface DashboardStats {
  totalTransactions: number;
  totalVolume: number;
  todayTransactions: number;
  todayVolume: number;
  completedCount: number;
  pendingCount: number;
  failedCount: number;
  totalFees: number;
  recentActivity: any[];
}

interface ApiKeyData {
  id: string;
  name: string;
  key: string;
  secret: string;
  environment: string;
  active: boolean;
}

interface PlatformConfig {
  id: string;
  businessName: string;
  shortcode: string;
  passkey: string;
  consumerKey: string;
  consumerSecret: string;
  environment: string;
  channelType: string;
  callbackBase: string;
  serviceFeePct: number;
  minServiceFee: number;
  isConfigured: boolean;
}

// ─── Main App ───
export default function Home() {
  const [view, setView] = useState<View>('landing');
  const [merchant, setMerchant] = useState<MerchantData | null>(null);
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [transactions, setTransactions] = useState<any[]>([]);
  const [apiKeys, setApiKeys] = useState<ApiKeyData[]>([]);
  const [platformConfig, setPlatformConfig] = useState<PlatformConfig | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [loading, setLoading] = useState(false);

  // ─── Auth Functions ───
  const register = async (data: { businessName: string; email: string; phone: string; password: string }) => {
    setLoading(true);
    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      const json = await res.json();
      if (json.success) {
        setMerchant(json.merchant);
        if (json.apiKeys) setApiKeys([
          { id: '1', name: 'Sandbox Key', key: json.apiKeys.sandbox.key, secret: json.apiKeys.sandbox.secret, environment: 'sandbox', active: true },
          { id: '2', name: 'Live Key', key: json.apiKeys.live.key, secret: json.apiKeys.live.secret, environment: 'live', active: true },
        ]);
        setView('dashboard');
        loadDashboard(json.merchant.id);
      } else {
        alert(json.error || 'Registration failed');
      }
    } catch { alert('Network error'); }
    setLoading(false);
  };

  const login = async (email: string, password: string) => {
    setLoading(true);
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });
      const json = await res.json();
      if (json.success) {
        setMerchant(json.merchant);
        if (json.apiKeys) setApiKeys(json.apiKeys);
        setView('dashboard');
        loadDashboard(json.merchant.id);
      } else {
        alert(json.error || 'Login failed');
      }
    } catch { alert('Network error'); }
    setLoading(false);
  };

  const loadDashboard = async (merchantId?: string) => {
    const mid = merchantId || merchant?.id;
    if (!mid) return;
    try {
      const res = await fetch('/api/dashboard', {
        headers: { 'x-merchant-id': mid },
      });
      const json = await res.json();
      if (json.stats) setStats(json.stats);
      if (json.recentTransactions) setTransactions(json.recentTransactions);
      if (json.apiKeys) setApiKeys(json.apiKeys);
      if (json.platformConfig) setPlatformConfig(json.platformConfig);
    } catch (e) { console.error('Dashboard load error', e); }
  };

  const loadPlatformConfig = async () => {
    try {
      const res = await fetch('/api/platform/settings');
      const json = await res.json();
      if (json.settings) setPlatformConfig(json.settings);
    } catch (e) { console.error('Platform config load error', e); }
  };

  // Auto-refresh dashboard
  useEffect(() => {
    if (view !== 'dashboard' && view !== 'transactions') return;
    const interval = setInterval(() => loadDashboard(), 15000);
    return () => clearInterval(interval);
  }, [view, merchant]);

  // ─── Navigation Items ───
  const navItems = [
    { id: 'dashboard' as View, label: 'Dashboard', icon: BarChart3 },
    { id: 'transactions' as View, label: 'Transactions', icon: CreditCard },
    { id: 'stk-push' as View, label: 'STK Push', icon: Phone },
    { id: 'platform-settings' as View, label: 'Platform Setup', icon: Settings },
    { id: 'api-keys' as View, label: 'API Keys', icon: Key },
    { id: 'docs' as View, label: 'API Docs', icon: BookOpen },
  ];

  // ─── Render ───
  return (
    <div className="min-h-screen bg-gray-50">
      <AnimatePresence mode="wait">
        {view === 'landing' && (
          <LandingPage onLogin={() => setView('login')} onRegister={() => setView('register')} />
        )}
        {view === 'login' && (
          <AuthPage mode="login" loading={loading} onSubmit={login} onSwitch={() => setView('register')} onBack={() => setView('landing')} />
        )}
        {view === 'register' && (
          <AuthPage mode="register" loading={loading} onSubmit={register} onSwitch={() => setView('login')} onBack={() => setView('landing')} />
        )}
        {(view === 'dashboard' || view === 'transactions' || view === 'api-keys' || view === 'platform-settings' || view === 'docs' || view === 'stk-push') && merchant && (
          <DashboardLayout
            merchant={merchant} navItems={navItems} currentView={view} onViewChange={setView}
            sidebarOpen={sidebarOpen} onSidebarToggle={() => setSidebarOpen(!sidebarOpen)}
            platformConfig={platformConfig}
            onLogout={() => { setMerchant(null); setView('landing'); }}
          >
            {view === 'dashboard' && <DashboardView merchant={merchant} stats={stats} transactions={transactions} onRefresh={() => loadDashboard()} />}
            {view === 'transactions' && <TransactionsView transactions={transactions} onRefresh={() => loadDashboard()} />}
            {view === 'stk-push' && <STKPushView merchantId={merchant.id} apiKeys={apiKeys} platformConfig={platformConfig} onRefresh={() => loadDashboard()} />}
            {view === 'api-keys' && <ApiKeysView merchantId={merchant.id} apiKeys={apiKeys} onUpdate={() => loadDashboard()} />}
            {view === 'platform-settings' && <PlatformSettingsView config={platformConfig} onUpdate={() => { loadPlatformConfig(); loadDashboard(); }} />}
            {view === 'docs' && <DocsView apiKeys={apiKeys} />}
          </DashboardLayout>
        )}
      </AnimatePresence>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════
// LANDING PAGE
// ═══════════════════════════════════════════════════════════
function LandingPage({ onLogin, onRegister }: { onLogin: () => void; onRegister: () => void }) {
  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="min-h-screen">
      <nav className="border-b bg-white/80 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 bg-gradient-to-br from-green-500 to-emerald-600 rounded-xl flex items-center justify-center">
              <Zap className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold text-gray-900">ToxicPay</span>
          </div>
          <div className="flex items-center gap-3">
            <Button variant="ghost" onClick={onLogin}>Sign In</Button>
            <Button className="bg-green-600 hover:bg-green-700" onClick={onRegister}>Get Started Free</Button>
          </div>
        </div>
      </nav>

      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-green-50 via-emerald-50 to-white" />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 py-20 sm:py-32">
          <div className="text-center max-w-3xl mx-auto">
            <Badge className="bg-green-100 text-green-700 border-green-200 mb-6">Built for Kenya</Badge>
            <h1 className="text-4xl sm:text-6xl font-extrabold text-gray-900 mb-6 leading-tight">
              M-Pesa STK Push,<br />
              <span className="text-green-600">Your Own Gateway.</span>
            </h1>
            <p className="text-lg sm:text-xl text-gray-600 mb-10 max-w-2xl mx-auto">
              Build your own payment platform like SwiftWallet. ToxicPay gives you the API, dashboard, and M-Pesa integration. Your merchants just need API keys.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-green-600 hover:bg-green-700 h-14 px-8 text-lg" onClick={onRegister}>
                Start Free <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
              <Button size="lg" variant="outline" className="h-14 px-8 text-lg" onClick={onLogin}>
                Sign In
              </Button>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Your Own Payment Platform</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">You are the aggregator. Merchants use YOUR API. You control the M-Pesa integration.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { icon: Phone, title: 'STK Push (C2B)', desc: 'Send M-Pesa payment prompts directly to customers\' phones. They enter PIN, you get paid.' },
              { icon: Key, title: 'Merchant API Keys', desc: 'Generate API keys for your merchants. They integrate with your API, not Daraja directly.' },
              { icon: Globe, title: 'Webhook Callbacks', desc: 'Instant notifications when payments complete. Automatic retries for failed deliveries.' },
              { icon: Shield, title: 'You Are the Gateway', desc: 'Like SwiftWallet - you configure Daraja once, all merchants go through your platform.' },
              { icon: Smartphone, title: 'Interactive Demo', desc: 'Test the full flow with a realistic M-Pesa phone mockup. No credentials needed.' },
              { icon: Wallet, title: 'Service Wallet', desc: 'Pay-as-you-go pricing for your merchants. KES 1,000 free credit on signup.' },
            ].map((f, i) => (
              <Card key={i} className="border-0 shadow-md hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center mb-4">
                    <f.icon className="w-6 h-6 text-green-600" />
                  </div>
                  <h3 className="text-lg font-bold text-gray-900 mb-2">{f.title}</h3>
                  <p className="text-gray-600 text-sm">{f.desc}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-gray-900 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Accept Payments in 3 Lines</h2>
          </div>
          <div className="max-w-2xl mx-auto bg-gray-800 rounded-2xl p-6 font-mono text-sm overflow-x-auto">
            <div className="text-gray-500 mb-2"># Initiate STK Push via ToxicPay API</div>
            <div><span className="text-green-400">curl</span> -X POST https://toxicpay.co.ke/api/v1/stk/initiate \</div>
            <div className="ml-4">-H <span className="text-yellow-300">&quot;Authorization: Bearer tpk_test_...&quot;</span> \</div>
            <div className="ml-4">-d <span className="text-yellow-300">&apos;&#123;&quot;phone&quot;:&quot;0795314221&quot;,&quot;amount&quot;:1500&#125;&apos;</span></div>
            <div className="mt-4 text-gray-500"># Response</div>
            <div className="text-green-300">&#123;&quot;success&quot;:true, &quot;status&quot;:&quot;INITIATED&quot;, &quot;transaction_id&quot;:&quot;TPX...&quot;&#125;</div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 text-center">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Simple Pricing</h2>
          <p className="text-gray-600 mb-12">No setup fees. No monthly fees. You only pay when you get paid.</p>
          <Card className="max-w-md mx-auto border-2 border-green-500 shadow-xl">
            <CardContent className="p-8">
              <div className="text-5xl font-extrabold text-green-600 mb-2">1.5%</div>
              <div className="text-gray-500 mb-6">per successful transaction</div>
              <div className="space-y-3 text-left">
                {['No setup fees', 'No monthly charges', 'KES 1,000 free credit on signup', 'No charge for failed payments', 'Demo mode for testing'].map((item, i) => (
                  <div key={i} className="flex items-center gap-2 text-sm text-gray-700">
                    <CheckCircle2 className="w-4 h-4 text-green-500 shrink-0" />{item}
                  </div>
                ))}
              </div>
              <Button className="w-full mt-6 bg-green-600 hover:bg-green-700" size="lg" onClick={onRegister}>
                Get Started Free
              </Button>
            </CardContent>
          </Card>
        </div>
      </section>

      <footer className="py-10 bg-gray-900 text-gray-400 text-center text-sm">
        <p>&copy; {new Date().getFullYear()} ToxicPay by Toxic Tech Kenya. All rights reserved.</p>
      </footer>
    </motion.div>
  );
}

// ═══════════════════════════════════════════════════════════
// AUTH PAGE
// ═══════════════════════════════════════════════════════════
function AuthPage({ mode, loading, onSubmit, onSwitch, onBack }: any) {
  const [form, setForm] = useState({ businessName: '', email: '', phone: '', password: '' });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (mode === 'login') {
      onSubmit(form.email, form.password);
    } else {
      onSubmit(form);
    }
  };

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }}
      className="min-h-screen flex items-center justify-center bg-gradient-to-br from-green-50 to-white p-4">
      <Card className="w-full max-w-md border-0 shadow-xl">
        <CardContent className="p-8">
          <button onClick={onBack} className="text-sm text-gray-400 hover:text-gray-600 mb-6 flex items-center gap-1">← Back</button>
          <div className="flex items-center gap-2 mb-6">
            <div className="w-10 h-10 bg-gradient-to-br from-green-500 to-emerald-600 rounded-xl flex items-center justify-center">
              <Zap className="w-6 h-6 text-white" />
            </div>
            <span className="text-2xl font-bold text-gray-900">ToxicPay</span>
          </div>
          <h2 className="text-xl font-bold text-gray-900 mb-1">{mode === 'login' ? 'Welcome back' : 'Create your account'}</h2>
          <p className="text-gray-500 text-sm mb-6">{mode === 'login' ? 'Sign in to your dashboard' : 'Get KES 1,000 free credit on signup'}</p>
          <form onSubmit={handleSubmit} className="space-y-4">
            {mode === 'register' && (
              <>
                <div><Label>Business Name</Label><Input placeholder="Toxic Tech Kenya" value={form.businessName} onChange={e => setForm({ ...form, businessName: e.target.value })} required className="h-11" /></div>
                <div><Label>Phone Number</Label><Input placeholder="0795314221" value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} required className="h-11" /></div>
              </>
            )}
            <div><Label>Email</Label><Input type="email" placeholder="you@business.com" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} required className="h-11" /></div>
            <div><Label>Password</Label><Input type="password" placeholder="••••••••" value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} required className="h-11" minLength={6} /></div>
            <Button type="submit" className="w-full bg-green-600 hover:bg-green-700 h-12 text-base font-semibold" disabled={loading}>
              {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : mode === 'login' ? 'Sign In' : 'Create Account'}
            </Button>
          </form>
          <div className="mt-4 text-center text-sm text-gray-500">
            {mode === 'login' ? "Don't have an account? " : "Already have an account? "}
            <button onClick={onSwitch} className="text-green-600 font-semibold hover:underline">{mode === 'login' ? 'Sign up' : 'Sign in'}</button>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

// ═══════════════════════════════════════════════════════════
// DASHBOARD LAYOUT
// ═══════════════════════════════════════════════════════════
function DashboardLayout({ merchant, navItems, currentView, onViewChange, sidebarOpen, onSidebarToggle, onLogout, platformConfig, children }: any) {
  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="min-h-screen flex">
      {/* Sidebar - Desktop */}
      <aside className="hidden md:flex flex-col w-64 bg-gray-900 text-white shrink-0">
        <div className="p-4 border-b border-gray-800">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-green-500 rounded-lg flex items-center justify-center"><Zap className="w-4 h-4 text-white" /></div>
            <span className="font-bold text-lg">ToxicPay</span>
          </div>
          {platformConfig && (
            <Badge className={`mt-2 text-[10px] ${platformConfig.isConfigured ? 'bg-green-800 text-green-300' : 'bg-yellow-800 text-yellow-300'}`}>
              {platformConfig.isConfigured ? `LIVE: ${platformConfig.channelType === 'till' ? 'Till' : 'Paybill'} ${platformConfig.shortcode}` : 'DEMO MODE'}
            </Badge>
          )}
        </div>
        <nav className="flex-1 p-3 space-y-1">
          {navItems.map((item: any) => (
            <button key={item.id} onClick={() => onViewChange(item.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-colors ${
                currentView === item.id ? 'bg-green-600 text-white' : 'text-gray-400 hover:bg-gray-800 hover:text-white'
              }`}>
              <item.icon className="w-4 h-4" />{item.label}
            </button>
          ))}
        </nav>
        <div className="p-3 border-t border-gray-800">
          <div className="px-3 py-2 mb-2">
            <div className="text-xs text-gray-500">Wallet Balance</div>
            <div className="text-lg font-bold text-green-400">KES {merchant.serviceWallet?.toLocaleString()}</div>
          </div>
          <button onClick={onLogout} className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-gray-400 hover:bg-gray-800 hover:text-white">
            <LogOut className="w-4 h-4" /> Sign Out
          </button>
        </div>
      </aside>

      {/* Mobile sidebar overlay */}
      <AnimatePresence>
        {sidebarOpen && (
          <>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/50 z-40 md:hidden" onClick={onSidebarToggle} />
            <motion.aside initial={{ x: -280 }} animate={{ x: 0 }} exit={{ x: -280 }}
              className="fixed left-0 top-0 bottom-0 w-64 bg-gray-900 text-white z-50 md:hidden">
              <div className="p-4 flex justify-between items-center border-b border-gray-800">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 bg-green-500 rounded-lg flex items-center justify-center"><Zap className="w-4 h-4 text-white" /></div>
                  <span className="font-bold">ToxicPay</span>
                </div>
                <button onClick={onSidebarToggle}><X className="w-5 h-5" /></button>
              </div>
              <nav className="p-3 space-y-1">
                {navItems.map((item: any) => (
                  <button key={item.id} onClick={() => { onViewChange(item.id); onSidebarToggle(); }}
                    className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm ${
                      currentView === item.id ? 'bg-green-600 text-white' : 'text-gray-400 hover:bg-gray-800'
                    }`}>
                    <item.icon className="w-4 h-4" />{item.label}
                  </button>
                ))}
              </nav>
            </motion.aside>
          </>
        )}
      </AnimatePresence>

      {/* Main content */}
      <div className="flex-1 flex flex-col min-w-0">
        <header className="h-16 border-b bg-white flex items-center px-4 gap-4 shrink-0">
          <button className="md:hidden" onClick={onSidebarToggle}><Menu className="w-6 h-6" /></button>
          <div className="flex-1">
            <h1 className="text-lg font-semibold text-gray-900">
              {navItems.find((n: any) => n.id === currentView)?.label || 'Dashboard'}
            </h1>
          </div>
          <div className="flex items-center gap-3">
            <Badge variant="outline" className="hidden sm:flex">{merchant.businessName}</Badge>
            <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center text-green-700 font-bold text-sm">
              {merchant.businessName[0]}
            </div>
          </div>
        </header>
        <main className="flex-1 overflow-auto p-4 sm:p-6">{children}</main>
      </div>
    </motion.div>
  );
}

// ═══════════════════════════════════════════════════════════
// DASHBOARD VIEW
// ═══════════════════════════════════════════════════════════
function DashboardView({ merchant, stats, transactions, onRefresh }: any) {
  if (!stats) return <div className="text-center py-12 text-gray-400"><Loader2 className="w-8 h-8 animate-spin mx-auto mb-2" />Loading...</div>;

  const statCards = [
    { label: 'Total Volume', value: `KES ${stats.totalVolume.toLocaleString()}`, icon: DollarSign, color: 'text-green-600', bg: 'bg-green-50' },
    { label: "Today's Volume", value: `KES ${stats.todayVolume.toLocaleString()}`, icon: TrendingUp, color: 'text-blue-600', bg: 'bg-blue-50' },
    { label: 'Total Transactions', value: stats.totalTransactions.toString(), icon: CreditCard, color: 'text-purple-600', bg: 'bg-purple-50' },
    { label: 'Success Rate', value: stats.totalTransactions > 0 ? `${Math.round((stats.completedCount / stats.totalTransactions) * 100)}%` : 'N/A', icon: Activity, color: 'text-emerald-600', bg: 'bg-emerald-50' },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Welcome, {merchant.businessName}!</h2>
          <p className="text-gray-500">Your payment overview</p>
        </div>
        <Button variant="outline" onClick={onRefresh} size="sm"><RefreshCw className="w-4 h-4 mr-1" /> Refresh</Button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map((s, i) => (
          <Card key={i} className="border-0 shadow-sm">
            <CardContent className="p-5">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-gray-500 mb-1">{s.label}</p>
                  <p className="text-2xl font-bold text-gray-900">{s.value}</p>
                </div>
                <div className={`w-10 h-10 ${s.bg} rounded-xl flex items-center justify-center`}>
                  <s.icon className={`w-5 h-5 ${s.color}`} />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-3 gap-4">
        <Card className="border-0 shadow-sm"><CardContent className="p-4 text-center"><div className="text-2xl font-bold text-green-600">{stats.completedCount}</div><div className="text-xs text-gray-500">Completed</div></CardContent></Card>
        <Card className="border-0 shadow-sm"><CardContent className="p-4 text-center"><div className="text-2xl font-bold text-yellow-600">{stats.pendingCount}</div><div className="text-xs text-gray-500">Pending</div></CardContent></Card>
        <Card className="border-0 shadow-sm"><CardContent className="p-4 text-center"><div className="text-2xl font-bold text-red-600">{stats.failedCount}</div><div className="text-xs text-gray-500">Failed</div></CardContent></Card>
      </div>

      <Card className="border-0 shadow-sm">
        <CardHeader className="pb-3"><CardTitle className="text-base">Recent Transactions</CardTitle></CardHeader>
        <CardContent>
          {transactions.length === 0 ? (
            <p className="text-gray-400 text-sm text-center py-8">No transactions yet. Try the STK Push!</p>
          ) : (
            <div className="space-y-2 max-h-96 overflow-y-auto">
              {transactions.slice(0, 15).map((t: any) => (
                <div key={t.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                      t.status === 'completed' ? 'bg-green-100' : t.status === 'failed' ? 'bg-red-100' : 'bg-yellow-100'
                    }`}>
                      {t.status === 'completed' ? <CheckCircle2 className="w-4 h-4 text-green-600" /> :
                       t.status === 'failed' ? <XCircle className="w-4 h-4 text-red-600" /> :
                       <Clock className="w-4 h-4 text-yellow-600" />}
                    </div>
                    <div>
                      <div className="text-sm font-medium text-gray-900">KES {t.amount.toLocaleString()} {t.isDemo && <span className="text-xs text-gray-400">(demo)</span>}</div>
                      <div className="text-xs text-gray-500">{t.phone}</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <Badge variant={t.status === 'completed' ? 'default' : t.status === 'failed' ? 'destructive' : 'secondary'}
                      className={t.status === 'completed' ? 'bg-green-100 text-green-700' : t.status === 'initiated' ? 'bg-yellow-100 text-yellow-700' : undefined}>
                      {t.status}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════
// TRANSACTIONS VIEW
// ═══════════════════════════════════════════════════════════
function TransactionsView({ transactions, onRefresh }: any) {
  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-lg font-bold">All Transactions</h2>
        <Button variant="outline" size="sm" onClick={onRefresh}><RefreshCw className="w-4 h-4 mr-1" /> Refresh</Button>
      </div>
      <Card className="border-0 shadow-sm">
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead><tr className="border-b bg-gray-50">
                <th className="text-left p-3 text-gray-500 font-medium">Amount</th>
                <th className="text-left p-3 text-gray-500 font-medium">Phone</th>
                <th className="text-left p-3 text-gray-500 font-medium">Status</th>
                <th className="text-left p-3 text-gray-500 font-medium">Type</th>
                <th className="text-left p-3 text-gray-500 font-medium">Date</th>
              </tr></thead>
              <tbody>
                {transactions.length === 0 ? (
                  <tr><td colSpan={5} className="text-center py-12 text-gray-400">No transactions yet</td></tr>
                ) : transactions.map((t: any) => (
                  <tr key={t.id} className="border-b last:border-0 hover:bg-gray-50">
                    <td className="p-3 font-semibold text-gray-900">KES {t.amount.toLocaleString()}</td>
                    <td className="p-3 font-mono text-gray-600">{t.phone}</td>
                    <td className="p-3">
                      <Badge variant={t.status === 'completed' ? 'default' : t.status === 'failed' ? 'destructive' : 'secondary'}
                        className={t.status === 'completed' ? 'bg-green-100 text-green-700' : t.status === 'initiated' ? 'bg-yellow-100 text-yellow-700' : undefined}>
                        {t.status}
                      </Badge>
                    </td>
                    <td className="p-3 text-gray-500">{t.isDemo ? 'Demo' : 'Live'}</td>
                    <td className="p-3 text-gray-500">{new Date(t.createdAt).toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════
// STK PUSH VIEW - WITH INTERACTIVE PHONE MOCKUP
// ═══════════════════════════════════════════════════════════
function STKPushView({ merchantId, apiKeys, platformConfig, onRefresh }: {
  merchantId: string;
  apiKeys: ApiKeyData[];
  platformConfig: PlatformConfig | null;
  onRefresh: () => void;
}) {
  const [phone, setPhone] = useState('0795314221');
  const [amount, setAmount] = useState('100');
  const [status, setStatus] = useState<STKStatus>('idle');
  const [error, setError] = useState('');
  const [txId, setTxId] = useState('');
  const [checkoutId, setCheckoutId] = useState('');
  const [isDemoTx, setIsDemoTx] = useState(false);
  const [mpesaStep, setMpesaStep] = useState<'prompt' | 'pin' | 'processing' | 'result'>('prompt');
  const [pinDigits, setPinDigits] = useState<string[]>([]);
  const [countdown, setCountdown] = useState(120);
  const [debugLog, setDebugLog] = useState<string[]>([]);

  const sandboxKey = apiKeys.find(k => k.environment === 'sandbox');
  const apiKey = sandboxKey?.key || '';
  const isConfigured = platformConfig?.isConfigured;

  const addLog = (msg: string) => {
    const time = new Date().toLocaleTimeString();
    setDebugLog(prev => [...prev.slice(-14), `[${time}] ${msg}`]);
  };

  const formatIntlPhone = (p: string): string => {
    const digits = p.replace(/\D/g, '');
    if (digits.startsWith('254')) return digits;
    if (digits.startsWith('0')) return '254' + digits.substring(1);
    if (digits.startsWith('7') || digits.startsWith('1')) return '254' + digits;
    return digits;
  };

  const isValidPhone = (p: string): boolean => /^254[0-9]{9}$/.test(formatIntlPhone(p));

  // Countdown for real Daraja transactions
  useEffect(() => {
    if (status !== 'pending' || isDemoTx) return;
    const timer = setInterval(() => {
      setCountdown(prev => {
        if (prev <= 1) { setStatus('timeout'); setError('Transaction timed out'); return 0; }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [status, isDemoTx]);

  // Polling for real Daraja transactions
  useEffect(() => {
    if (status !== 'pending' || !checkoutId || !apiKey || isDemoTx) return;
    let pollAttempt = 0;
    const interval = setInterval(async () => {
      pollAttempt++;
      addLog(`Polling Daraja... (attempt ${pollAttempt})`);
      try {
        const res = await fetch('/api/v1/stk/query', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${apiKey}` },
          body: JSON.stringify({ checkout_request_id: checkoutId }),
        });
        const data = await res.json();
        addLog(`Status: ${data.status} (code: ${data.result_code || 'N/A'})`);
        if (data.status === 'COMPLETED') {
          setStatus('success'); addLog('Payment completed!'); clearInterval(interval);
        } else if (data.status === 'FAILED' || data.status === 'CANCELLED') {
          setStatus('failed'); setError(data.result_desc || 'Payment failed'); clearInterval(interval);
        }
      } catch { addLog('Poll failed, retrying...'); }
    }, 3000);
    return () => clearInterval(interval);
  }, [status, checkoutId, apiKey, isDemoTx]);

  const handlePush = async () => {
    if (!apiKey) { setError('No API key found.'); return; }
    if (!isValidPhone(phone)) { setError('Enter a valid Safaricom number'); return; }
    const numAmount = parseFloat(amount);
    if (!numAmount || numAmount < 1) { setError('Amount must be at least KES 1'); return; }

    const formattedPhone = formatIntlPhone(phone);
    addLog(`Initiating STK Push to ${formattedPhone} for KES ${numAmount}`);
    setStatus('initiating');
    setError('');
    setCountdown(120);
    setPinDigits([]);
    setMpesaStep('prompt');

    try {
      const res = await fetch('/api/v1/stk/initiate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${apiKey}` },
        body: JSON.stringify({ phone: formattedPhone, amount: numAmount }),
      });
      const data = await res.json();
      addLog(`API: success=${data.success} isDemo=${data.isDemo}`);

      if (data.success) {
        setTxId(data.transactionId);
        setCheckoutId(data.checkoutRequestId);
        setIsDemoTx(data.isDemo);
        setStatus('pending');
        if (data.isDemo) {
          addLog('DEMO mode - showing M-Pesa phone mockup');
          setMpesaStep('prompt');
        } else {
          addLog('REAL Daraja - check your phone for M-Pesa prompt!');
        }
      } else {
        setStatus('failed');
        setError(data.error || 'Failed');
        addLog(`Failed: ${data.error}`);
      }
    } catch {
      setStatus('failed');
      setError('Network error');
      addLog('Network error');
    }
  };

  // Demo mode: handle PIN entry on the phone mockup
  const handlePinDigit = async (digit: string) => {
    if (mpesaStep !== 'pin' || pinDigits.length >= 4) return;
    const newPin = [...pinDigits, digit];
    setPinDigits(newPin);

    if (newPin.length === 4) {
      setMpesaStep('processing');
      addLog('PIN entered, processing payment...');

      // Simulate processing delay
      setTimeout(async () => {
        const success = Math.random() > 0.1; // 90% success rate
        try {
          const res = await fetch('/api/v1/stk/demo-complete', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ transaction_id: txId, success }),
          });
          const data = await res.json();
          if (data.success) {
            setMpesaStep('result');
            if (success) {
              setStatus('success');
              addLog('Demo payment completed!');
            } else {
              setStatus('failed');
              setError('Payment was declined (demo simulation)');
              addLog('Demo payment failed');
            }
            onRefresh();
          }
        } catch {
          setStatus('failed');
          setError('Processing error');
        }
      }, 2000);
    }
  };

  const handleCancelDemo = async () => {
    try {
      await fetch('/api/v1/stk/demo-complete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ transaction_id: txId, success: false }),
      });
    } catch {}
    setStatus('failed');
    setError('Payment cancelled');
    addLog('User cancelled demo payment');
    onRefresh();
  };

  const reset = () => {
    setStatus('idle');
    setError('');
    setTxId('');
    setCheckoutId('');
    setIsDemoTx(false);
    setPinDigits([]);
    setMpesaStep('prompt');
    setCountdown(120);
    setDebugLog([]);
  };

  const maskedPhone = () => {
    const f = formatIntlPhone(phone);
    return f.slice(0, 4) + '****' + f.slice(-3);
  };

  return (
    <div className="max-w-5xl mx-auto">
      <div className="text-center mb-6">
        <h2 className="text-xl font-bold text-gray-900">STK Push</h2>
        <p className="text-gray-500 text-sm">
          {isConfigured ? `Real M-Pesa prompts - ${platformConfig?.channelType === 'till' ? `Till ${platformConfig?.shortcode}` : `Paybill ${platformConfig?.shortcode}`}` : 'Demo mode - interactive M-Pesa simulation'}
        </p>
        <Badge className={`mt-2 ${isConfigured ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}`}>
          {isConfigured ? 'DARAJA CONNECTED' : 'DEMO MODE - Add Daraja credentials in Platform Setup for real prompts'}
        </Badge>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* LEFT: Input Form */}
        <div className="space-y-4">
          {status === 'idle' && (
            <Card className="border-0 shadow-lg">
              <CardContent className="p-6 space-y-4">
                <div>
                  <Label>Phone Number (Safaricom)</Label>
                  <div className="relative mt-1">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm font-semibold text-green-600 bg-green-50 px-2 py-0.5 rounded">+254</span>
                    <Input placeholder="0795314221" value={phone}
                      onChange={e => { setPhone(e.target.value.replace(/[^\d\s]/g, '')); setError(''); }}
                      className="pl-20 h-12 text-lg font-mono border-green-200 focus:border-green-500" maxLength={12} />
                  </div>
                  <p className="text-xs text-gray-400 mt-1">Test: 0795314221</p>
                </div>
                <div>
                  <Label>Amount (KES)</Label>
                  <Input type="number" placeholder="100" value={amount}
                    onChange={e => { setAmount(e.target.value); setError(''); }}
                    className="mt-1 h-12 text-lg font-mono border-green-200 focus:border-green-500" min="1" />
                </div>
                <div className="flex gap-2">
                  {['100', '500', '1000', '5000'].map(v => (
                    <Button key={v} variant="outline" size="sm" className="flex-1 text-green-700 border-green-200 hover:bg-green-50" onClick={() => setAmount(v)}>
                      {parseInt(v).toLocaleString()}
                    </Button>
                  ))}
                </div>
                {error && (
                  <div className="flex items-center gap-2 text-red-500 text-sm bg-red-50 p-3 rounded-lg">
                    <AlertCircle className="w-4 h-4 shrink-0" />{error}
                  </div>
                )}
                <Button onClick={handlePush}
                  className="w-full h-14 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-lg font-bold shadow-lg shadow-green-200"
                  disabled={!isValidPhone(phone) || !parseFloat(amount)}>
                  <Phone className="w-5 h-5 mr-2" /> Send STK Push
                </Button>
              </CardContent>
            </Card>
          )}

          {/* Status displays for initiating/pending/success/failed */}
          {(status === 'initiating' || (status === 'pending' && !isDemoTx)) && (
            <Card className="border-0 shadow-lg">
              <CardContent className="p-8 flex flex-col items-center text-center">
                <motion.div animate={{ rotate: 360 }} transition={{ duration: 2, repeat: Infinity, ease: 'linear' }}
                  className="w-20 h-20 bg-gradient-to-br from-green-500 to-emerald-600 rounded-full flex items-center justify-center mb-6">
                  <Phone className="w-10 h-10 text-white" />
                </motion.div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">
                  {status === 'initiating' ? 'Connecting to Safaricom...' : 'Check Your Phone!'}
                </h3>
                <p className="text-gray-500 mb-4">
                  {status === 'initiating' ? 'Sending STK Push request...' : `Enter M-Pesa PIN on ${maskedPhone()}`}
                </p>
                {status === 'pending' && !isDemoTx && (
                  <div className="text-3xl font-mono font-bold text-green-600">{countdown}s</div>
                )}
              </CardContent>
            </Card>
          )}

          {status === 'success' && (
            <Card className="border-0 shadow-lg">
              <CardContent className="p-8 flex flex-col items-center text-center">
                <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: 'spring', stiffness: 200 }}>
                  <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mb-4">
                    <CheckCircle2 className="w-10 h-10 text-green-600" />
                  </div>
                </motion.div>
                <h3 className="text-xl font-bold text-green-600 mb-2">Payment Successful!</h3>
                <p className="text-gray-500 mb-4">KES {parseFloat(amount).toLocaleString()} received from {maskedPhone()}</p>
                <Button onClick={reset} className="bg-green-600 hover:bg-green-700">New Payment</Button>
              </CardContent>
            </Card>
          )}

          {status === 'failed' && (
            <Card className="border-0 shadow-lg">
              <CardContent className="p-8 flex flex-col items-center text-center">
                <div className="w-20 h-20 bg-red-100 rounded-full flex items-center justify-center mb-4">
                  <XCircle className="w-10 h-10 text-red-600" />
                </div>
                <h3 className="text-xl font-bold text-red-600 mb-2">Payment Failed</h3>
                <p className="text-gray-500 mb-4">{error}</p>
                <Button onClick={reset} variant="outline">Try Again</Button>
              </CardContent>
            </Card>
          )}

          {status === 'timeout' && (
            <Card className="border-0 shadow-lg">
              <CardContent className="p-8 flex flex-col items-center text-center">
                <div className="w-20 h-20 bg-yellow-100 rounded-full flex items-center justify-center mb-4">
                  <Clock className="w-10 h-10 text-yellow-600" />
                </div>
                <h3 className="text-xl font-bold text-yellow-600 mb-2">Timed Out</h3>
                <p className="text-gray-500 mb-4">The transaction timed out. Please try again.</p>
                <Button onClick={reset} variant="outline">Try Again</Button>
              </CardContent>
            </Card>
          )}

          {/* Debug log */}
          {debugLog.length > 0 && (
            <Card className="border-0 shadow-sm">
              <CardContent className="p-3">
                <div className="text-xs font-mono text-gray-500 space-y-0.5 max-h-32 overflow-y-auto">
                  {debugLog.map((log, i) => <div key={i}>{log}</div>)}
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        {/* RIGHT: Phone Mockup (Demo Mode) */}
        <div className="flex justify-center">
          {status === 'pending' && isDemoTx ? (
            <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }}
              className="w-[280px] bg-gray-900 rounded-[2.5rem] p-3 shadow-2xl">
              {/* Phone frame */}
              <div className="bg-gray-900 rounded-[2rem] overflow-hidden">
                {/* Status bar */}
                <div className="flex items-center justify-between px-6 py-2 text-white text-xs">
                  <span>{new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                  <div className="flex items-center gap-1">
                    <div className="w-4 h-2 border border-white rounded-sm"><div className="w-2 h-full bg-green-400 rounded-sm" /></div>
                  </div>
                </div>

                {/* M-Pesa prompt screen */}
                <div className="bg-white min-h-[450px] flex flex-col">
                  {mpesaStep === 'prompt' && (
                    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex-1 flex flex-col p-4">
                      <div className="bg-green-600 text-white p-3 rounded-t-lg text-center">
                        <div className="text-sm font-bold">Lipa Na M-Pesa</div>
                      </div>
                      <div className="border border-t-0 border-gray-200 rounded-b-lg p-4 flex-1 space-y-3">
                        <div className="text-center text-gray-500 text-xs">STK Push Request</div>
                        <div className="space-y-2">
                          <div className="flex justify-between text-sm"><span className="text-gray-500">Business:</span><span className="font-semibold">{platformConfig?.businessName || 'Toxic Tech Kenya'}</span></div>
                          <div className="flex justify-between text-sm"><span className="text-gray-500">Amount:</span><span className="font-bold text-green-600">KES {parseFloat(amount).toLocaleString()}</span></div>
                          <div className="flex justify-between text-sm"><span className="text-gray-500">Account:</span><span className="font-mono">{phone.replace(/\D/g, '')}</span></div>
                          <div className="flex justify-between text-sm"><span className="text-gray-500">Paybill:</span><span className="font-mono">{platformConfig?.shortcode || '174379'}</span></div>
                        </div>
                        <Separator />
                        <Button onClick={() => setMpesaStep('pin')}
                          className="w-full bg-green-600 hover:bg-green-700 h-10 font-bold">
                          Enter PIN
                        </Button>
                        <Button onClick={handleCancelDemo} variant="outline" className="w-full h-8 text-xs">Cancel</Button>
                      </div>
                    </motion.div>
                  )}

                  {mpesaStep === 'pin' && (
                    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex-1 flex flex-col p-4">
                      <div className="bg-green-600 text-white p-3 rounded-t-lg text-center">
                        <div className="text-sm font-bold">Enter M-Pesa PIN</div>
                      </div>
                      <div className="border border-t-0 border-gray-200 rounded-b-lg p-4 flex-1 space-y-4">
                        <div className="text-center text-sm text-gray-500">
                          KES {parseFloat(amount).toLocaleString()} to {platformConfig?.businessName || 'Toxic Tech Kenya'}
                        </div>
                        {/* PIN dots */}
                        <div className="flex justify-center gap-3">
                          {[0, 1, 2, 3].map(i => (
                            <div key={i} className={`w-10 h-10 rounded-full border-2 flex items-center justify-center ${
                              i < pinDigits.length ? 'border-green-600 bg-green-600' : 'border-gray-300'
                            }`}>
                              {i < pinDigits.length && <div className="w-3 h-3 bg-white rounded-full" />}
                            </div>
                          ))}
                        </div>
                        {/* Number pad */}
                        <div className="grid grid-cols-3 gap-2 mt-2">
                          {['1', '2', '3', '4', '5', '6', '7', '8', '9', '', '0', '⌫'].map((key, i) => (
                            <button key={i}
                              onClick={() => {
                                if (key === '⌫') setPinDigits(prev => prev.slice(0, -1));
                                else if (key) handlePinDigit(key);
                              }}
                              className={`h-10 rounded-lg text-base font-bold transition-colors ${
                                key ? 'bg-gray-100 hover:bg-gray-200 active:bg-gray-300 text-gray-900' : ''
                              }`}
                              disabled={!key}
                            >
                              {key}
                            </button>
                          ))}
                        </div>
                        <Button onClick={handleCancelDemo} variant="ghost" className="w-full text-xs text-red-500">Cancel</Button>
                      </div>
                    </motion.div>
                  )}

                  {mpesaStep === 'processing' && (
                    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex-1 flex flex-col items-center justify-center p-4">
                      <Loader2 className="w-12 h-12 text-green-600 animate-spin mb-4" />
                      <div className="text-sm font-bold text-gray-900">Processing Payment...</div>
                      <div className="text-xs text-gray-500 mt-1">Please wait</div>
                    </motion.div>
                  )}

                  {mpesaStep === 'result' && status === 'success' && (
                    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex-1 flex flex-col p-4">
                      <div className="bg-green-600 text-white p-3 rounded-t-lg text-center">
                        <CheckCircle2 className="w-6 h-6 mx-auto mb-1" />
                        <div className="text-sm font-bold">Payment Successful</div>
                      </div>
                      <div className="border border-t-0 border-gray-200 rounded-b-lg p-4 space-y-2">
                        <div className="flex justify-between text-sm"><span className="text-gray-500">Amount:</span><span className="font-bold text-green-600">KES {parseFloat(amount).toLocaleString()}</span></div>
                        <div className="flex justify-between text-sm"><span className="text-gray-500">From:</span><span className="font-mono">{maskedPhone()}</span></div>
                        <div className="flex justify-between text-sm"><span className="text-gray-500">To:</span><span className="font-mono">{platformConfig?.shortcode || '174379'}</span></div>
                        <div className="flex justify-between text-sm"><span className="text-gray-500">Receipt:</span><span className="font-mono text-xs">DHK{Date.now().toString(36).toUpperCase()}</span></div>
                        <Separator />
                        <div className="text-center text-xs text-green-600 font-semibold">Paid to {platformConfig?.businessName || 'Toxic Tech Kenya'}</div>
                      </div>
                    </motion.div>
                  )}
                </div>
              </div>
            </motion.div>
          ) : (
            /* Idle: show phone placeholder */
            <div className="w-[280px] bg-gray-200 rounded-[2.5rem] p-3 opacity-50 hidden lg:block">
              <div className="bg-gray-300 rounded-[2rem] min-h-[450px] flex items-center justify-center">
                <div className="text-center text-gray-500 p-6">
                  <Smartphone className="w-12 h-12 mx-auto mb-3" />
                  <p className="text-sm font-medium">M-Pesa Phone Preview</p>
                  <p className="text-xs mt-1">Send STK Push to see the interactive M-Pesa prompt here</p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════
// PLATFORM SETTINGS VIEW
// ═══════════════════════════════════════════════════════════
function PlatformSettingsView({ config, onUpdate }: { config: PlatformConfig | null; onUpdate: () => void }) {
  const getInitialForm = () => ({
    businessName: config?.businessName || 'TOXIC TECH PLUGER',
    shortcode: config?.shortcode || '3200841',
    passkey: config?.passkey || 'bfb279f9aa9bdbcf158e97dd71a467cd2e0c893059b10f78e6b72ada1ed2c919',
    consumerKey: config?.consumerKey || '',
    consumerSecret: config?.consumerSecret || '',
    environment: config?.environment || 'sandbox',
    channelType: config?.channelType || 'till',
    callbackBase: config?.callbackBase || '',
  });
  const [form, setForm] = useState(getInitialForm);
  const [saving, setSaving] = useState(false);
  const [showSecret, setShowSecret] = useState(false);
  const [msg, setMsg] = useState('');
  const [prevConfigId, setPrevConfigId] = useState('');

  // Sync form when config changes (e.g. after save + refresh)
  if (config && config.id !== prevConfigId) {
    setPrevConfigId(config.id);
    setForm(getInitialForm());
  }

  const handleSave = async () => {
    setSaving(true);
    setMsg('');
    try {
      const res = await fetch('/api/platform/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (data.success) {
        setMsg('Settings saved! ' + (data.isConfigured ? 'Daraja is connected - real STK Push will work now!' : 'Add Consumer Key/Secret to connect Daraja.'));
        onUpdate();
      } else {
        setMsg('Error: ' + data.error);
      }
    } catch {
      setMsg('Network error');
    }
    setSaving(false);
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div>
        <h2 className="text-xl font-bold text-gray-900">Platform Setup</h2>
        <p className="text-gray-500 text-sm">Configure your Daraja API credentials. This is set once for the entire platform.</p>
      </div>

      {/* How it works */}
      <Card className="border-green-200 bg-green-50">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <Info className="w-5 h-5 text-green-600 mt-0.5 shrink-0" />
            <div className="text-sm text-green-800 space-y-2">
              <p className="font-semibold">How ToxicPay Works (Like SwiftWallet):</p>
              <ol className="list-decimal ml-4 space-y-1">
                <li>You (Toxic Tech Kenya) configure Daraja credentials ONCE here</li>
                <li>Your merchants get API keys and use YOUR API</li>
                <li>All STK Push requests go through YOUR Daraja account</li>
                <li>Without Daraja credentials, the platform runs in DEMO mode (simulated payments)</li>
              </ol>
              <p className="font-semibold mt-3">To get Daraja credentials (FREE, takes 2 minutes):</p>
              <ol className="list-decimal ml-4 space-y-1">
                <li>Go to <span className="font-mono text-green-900">developer.safaricom.co.ke</span></li>
                <li>Create a free account and create an app</li>
                <li>Copy your Consumer Key and Consumer Secret</li>
                <li>Paste them below and save</li>
              </ol>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="border-0 shadow-lg">
        <CardContent className="p-6 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <Label>Business Name</Label>
              <Input value={form.businessName} onChange={e => setForm({ ...form, businessName: e.target.value })} className="mt-1" />
            </div>
            <div>
              <Label>Environment</Label>
              <select value={form.environment} onChange={e => setForm({ ...form, environment: e.target.value })}
                className="mt-1 w-full h-9 rounded-md border border-input bg-transparent px-3 py-1 text-sm">
                <option value="sandbox">Sandbox (Testing)</option>
                <option value="production">Production (Live)</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <Label>Channel Type</Label>
              <select value={form.channelType} onChange={e => setForm({ ...form, channelType: e.target.value })}
                className="mt-1 w-full h-9 rounded-md border border-input bg-transparent px-3 py-1 text-sm">
                <option value="till">Till Number (Buy Goods)</option>
                <option value="paybill">Paybill Number</option>
              </select>
              <p className="text-xs text-gray-400 mt-1">Till = CustomerBuyGoodsOnline, Paybill = CustomerPayBillOnline</p>
            </div>
            <div>
              <Label>{form.channelType === 'till' ? 'Till Number' : 'Paybill Number'}</Label>
              <Input value={form.shortcode} onChange={e => setForm({ ...form, shortcode: e.target.value })} className="mt-1 font-mono" placeholder={form.channelType === 'till' ? '3200841' : '174379'} />
              <p className="text-xs text-gray-400 mt-1">{form.channelType === 'till' ? 'Your M-Pesa Till number' : 'Sandbox: 174379'}</p>
            </div>
          </div>

          <div>
            <Label>Callback Base URL</Label>
            <Input value={form.callbackBase} onChange={e => setForm({ ...form, callbackBase: e.target.value })} className="mt-1" placeholder="https://toxicpay.co.ke" />
            <p className="text-xs text-gray-400 mt-1">Your public URL for Daraja callbacks (must be https)</p>
          </div>

          <div>
            <Label>Lipa na M-Pesa Passkey</Label>
            <Input value={form.passkey} onChange={e => setForm({ ...form, passkey: e.target.value })} className="mt-1 font-mono text-xs" />
            <p className="text-xs text-gray-400 mt-1">Sandbox: bfb279f9aa9bdbcf158e97dd71a467cd2e0c893059b10f78e6b72ada1ed2c919</p>
          </div>

          <Separator />
          <div>
            <h3 className="font-semibold text-gray-900 mb-2">Daraja API Credentials</h3>
            <p className="text-xs text-gray-500 mb-3">Get these from developer.safaricom.co.ke (free). Without these, the platform runs in DEMO mode.</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <Label>Consumer Key</Label>
                <Input value={form.consumerKey} onChange={e => setForm({ ...form, consumerKey: e.target.value })} className="mt-1 font-mono text-xs" placeholder="Paste your Consumer Key..." />
              </div>
              <div>
                <Label>Consumer Secret</Label>
                <div className="relative mt-1">
                  <Input type={showSecret ? 'text' : 'password'} value={form.consumerSecret} onChange={e => setForm({ ...form, consumerSecret: e.target.value })} className="font-mono text-xs pr-10" placeholder="Paste your Consumer Secret..." />
                  <button onClick={() => setShowSecret(!showSecret)} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
                    {showSecret ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <Badge className={config?.isConfigured ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}>
              {config?.isConfigured ? 'Daraja Connected' : 'Demo Mode (No Daraja Credentials)'}
            </Badge>
          </div>

          {msg && (
            <div className={`p-3 rounded-lg text-sm ${msg.includes('Error') ? 'bg-red-50 text-red-600' : 'bg-green-50 text-green-700'}`}>
              {msg}
            </div>
          )}

          <Button onClick={handleSave} className="w-full bg-green-600 hover:bg-green-700 h-12" disabled={saving}>
            {saving ? <Loader2 className="w-5 h-5 animate-spin" /> : <><Save className="w-4 h-4 mr-2" /> Save Platform Settings</>}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════
// API KEYS VIEW
// ═══════════════════════════════════════════════════════════
function ApiKeysView({ merchantId, apiKeys, onUpdate }: any) {
  const [showSecret, setShowSecret] = useState<string | null>(null);
  const [copied, setCopied] = useState<string | null>(null);

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopied(id);
    setTimeout(() => setCopied(null), 2000);
  };

  const createNewKey = async () => {
    try {
      const res = await fetch('/api/merchant/api-keys', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-merchant-id': merchantId },
        body: JSON.stringify({ name: `Key ${apiKeys.length + 1}`, environment: 'sandbox' }),
      });
      if (res.ok) onUpdate();
    } catch {}
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-lg font-bold">API Keys</h2>
        <Button onClick={createNewKey} size="sm" className="bg-green-600 hover:bg-green-700">
          <Plus className="w-4 h-4 mr-1" /> New Key
        </Button>
      </div>
      <div className="space-y-3">
        {apiKeys.map((key: ApiKeyData) => (
          <Card key={key.id} className="border-0 shadow-sm">
            <CardContent className="p-4">
              <div className="flex items-start justify-between">
                <div className="space-y-1 flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-medium text-gray-900">{key.name}</span>
                    <Badge className={key.environment === 'sandbox' ? 'bg-yellow-100 text-yellow-700' : 'bg-green-100 text-green-700'}>
                      {key.environment}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-2">
                    <code className="text-xs font-mono bg-gray-100 px-2 py-1 rounded truncate max-w-[300px]">{key.key}</code>
                    <button onClick={() => copyToClipboard(key.key, key.id)} className="text-gray-400 hover:text-gray-600">
                      {copied === key.id ? <CheckCircle2 className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
                    </button>
                  </div>
                  <div className="flex items-center gap-2">
                    <code className="text-xs font-mono bg-gray-100 px-2 py-1 rounded">
                      {showSecret === key.id ? key.secret : '••••••••••••••••'}
                    </code>
                    <button onClick={() => setShowSecret(showSecret === key.id ? null : key.id)} className="text-gray-400 hover:text-gray-600">
                      {showSecret === key.id ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                    <button onClick={() => copyToClipboard(key.secret, key.id + '-secret')} className="text-gray-400 hover:text-gray-600">
                      {copied === key.id + '-secret' ? <CheckCircle2 className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════
// API DOCS VIEW
// ═══════════════════════════════════════════════════════════
function DocsView({ apiKeys }: { apiKeys: ApiKeyData[] }) {
  const sandboxKey = apiKeys.find(k => k.environment === 'sandbox');
  const keyExample = sandboxKey?.key || 'tpk_test_YOUR_KEY_HERE';

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <h2 className="text-xl font-bold text-gray-900">API Documentation</h2>

      <Card className="border-0 shadow-sm">
        <CardHeader><CardTitle className="text-base">Base URL</CardTitle></CardHeader>
        <CardContent>
          <code className="text-sm font-mono bg-gray-100 px-3 py-2 rounded block">https://toxicpay.co.ke/api/v1</code>
        </CardContent>
      </Card>

      <Card className="border-0 shadow-sm">
        <CardHeader><CardTitle className="text-base">Authentication</CardTitle></CardHeader>
        <CardContent className="space-y-2">
          <p className="text-sm text-gray-600">Include your API key in the Authorization header:</p>
          <div className="bg-gray-900 text-gray-100 rounded-lg p-4 font-mono text-sm">
            Authorization: Bearer {keyExample.slice(0, 20)}...
          </div>
        </CardContent>
      </Card>

      <Card className="border-0 shadow-sm">
        <CardHeader><CardTitle className="text-base">POST /stk/initiate</CardTitle></CardHeader>
        <CardContent className="space-y-3">
          <p className="text-sm text-gray-600">Initiate an STK Push to a customer&apos;s phone.</p>
          <div className="bg-gray-900 text-gray-100 rounded-lg p-4 font-mono text-sm space-y-1">
            <div className="text-gray-500"># Request</div>
            <div>&#123;</div>
            <div className="ml-4">&quot;phone&quot;: &quot;0795314221&quot;,</div>
            <div className="ml-4">&quot;amount&quot;: 1500,</div>
            <div className="ml-4">&quot;external_reference&quot;: &quot;order_123&quot;,</div>
            <div className="ml-4">&quot;callback_url&quot;: &quot;https://yoursite.co.ke/webhook&quot;</div>
            <div>&#125;</div>
            <div className="text-gray-500 mt-2"># Response</div>
            <div className="text-green-300">&#123;&quot;success&quot;: true, &quot;status&quot;: &quot;INITIATED&quot;, &quot;transaction_id&quot;: &quot;TPX...&quot;, &quot;isDemo&quot;: true&#125;</div>
          </div>
        </CardContent>
      </Card>

      <Card className="border-0 shadow-sm">
        <CardHeader><CardTitle className="text-base">POST /stk/query</CardTitle></CardHeader>
        <CardContent className="space-y-3">
          <p className="text-sm text-gray-600">Check the status of an STK Push transaction.</p>
          <div className="bg-gray-900 text-gray-100 rounded-lg p-4 font-mono text-sm space-y-1">
            <div className="text-gray-500"># Request</div>
            <div>&#123;</div>
            <div className="ml-4">&quot;checkout_request_id&quot;: &quot;ws_CO_...&quot;</div>
            <div>&#125;</div>
            <div className="text-gray-500 mt-2"># Response</div>
            <div className="text-green-300">&#123;&quot;status&quot;: &quot;COMPLETED&quot;, &quot;mpesa_receipt&quot;: &quot;DHK...&quot;&#125;</div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
