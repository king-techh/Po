import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Toxic Tech Kenya - M-Pesa STK Push",
  description: "Pay instantly with M-Pesa STK Push. Toxic Tech Kenya - Lipa Na M-Pesa online payment.",
  keywords: ["M-Pesa", "STK Push", "Toxic Tech Kenya", "Lipa Na M-Pesa", "Safaricom", "Kenya", "Payment"],
  authors: [{ name: "Toxic Tech Kenya" }],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
  openGraph: {
    title: "Toxic Tech Kenya - M-Pesa STK Push",
    description: "Pay instantly with M-Pesa STK Push",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
