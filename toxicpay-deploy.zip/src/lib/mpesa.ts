/**
 * M-Pesa Daraja API Integration for Toxic Tech Kenya
 * STK Push (Lipa Na M-Pesa Online) implementation
 */

// Sandbox credentials - Replace with production credentials from developer.safaricom.co.ke
const CONSUMER_KEY = process.env.MPESA_CONSUMER_KEY || 'your_consumer_key';
const CONSUMER_SECRET = process.env.MPESA_CONSUMER_SECRET || 'your_consumer_secret';
const BUSINESS_SHORT_CODE = process.env.MPESA_SHORTCODE || '174379';
const PASSKEY = process.env.MPESA_PASSKEY || 'bfb279f9aa9bdbcf158e97dd71a467cd2e0c893059b10f78e6b72ada1ed2c919';

// API URLs - Sandbox vs Production
const BASE_URL = process.env.MPESA_ENV === 'production'
  ? 'https://api.safaricom.co.ke'
  : 'https://sandbox.safaricom.co.ke';

export interface MpesaTokenResponse {
  access_token: string;
  expires_in: string;
}

export interface STKPushResponse {
  MerchantRequestID: string;
  CheckoutRequestID: string;
  ResponseCode: string;
  ResponseDescription: string;
  CustomerMessage: string;
}

export interface STKQueryResponse {
  MerchantRequestID: string;
  CheckoutRequestID: string;
  ResponseCode: string;
  ResultCode: string;
  ResultDesc: string;
}

/**
 * Generate timestamp in YYYYMMDDHHmmss format
 */
export function generateTimestamp(): string {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  const hour = String(now.getHours()).padStart(2, '0');
  const minute = String(now.getMinutes()).padStart(2, '0');
  const second = String(now.getSeconds()).padStart(2, '0');
  return `${year}${month}${day}${hour}${minute}${second}`;
}

/**
 * Generate password: Base64(Shortcode + Passkey + Timestamp)
 */
export function generatePassword(timestamp: string): string {
  const raw = `${BUSINESS_SHORT_CODE}${PASSKEY}${timestamp}`;
  return Buffer.from(raw).toString('base64');
}

/**
 * Format phone number to international format (254XXXXXXXXX)
 */
export function formatPhoneNumber(phone: string): string {
  // Remove any spaces or dashes
  let cleaned = phone.replace(/[\s-]/g, '');

  // Handle different formats
  if (cleaned.startsWith('+254')) {
    cleaned = cleaned.substring(1); // Remove +
  } else if (cleaned.startsWith('0')) {
    cleaned = '254' + cleaned.substring(1); // Replace leading 0 with 254
  } else if (cleaned.startsWith('254')) {
    // Already in correct format
  } else if (cleaned.startsWith('7') || cleaned.startsWith('1')) {
    cleaned = '254' + cleaned; // Add 254 prefix
  }

  return cleaned;
}

/**
 * Get OAuth access token from M-Pesa API
 */
export async function getAccessToken(): Promise<MpesaTokenResponse> {
  const auth = Buffer.from(`${CONSUMER_KEY}:${CONSUMER_SECRET}`).toString('base64');

  const response = await fetch(`${BASE_URL}/oauth/v1/generate?grant_type=client_credentials`, {
    method: 'GET',
    headers: {
      Authorization: `Basic ${auth}`,
    },
  });

  if (!response.ok) {
    throw new Error(`Failed to get access token: ${response.status} ${response.statusText}`);
  }

  return response.json();
}

/**
 * Initiate STK Push request
 */
export async function initiateSTKPush(
  phoneNumber: string,
  amount: number,
  accountReference: string = 'Toxic Tech Kenya',
  transactionDesc: string = 'Payment to Toxic Tech Kenya'
): Promise<STKPushResponse> {
  const timestamp = generateTimestamp();
  const password = generatePassword(timestamp);
  const formattedPhone = formatPhoneNumber(phoneNumber);

  const tokenData = await getAccessToken();

  const response = await fetch(`${BASE_URL}/mpesa/stkpush/v1/processrequest`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${tokenData.access_token}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      BusinessShortCode: BUSINESS_SHORT_CODE,
      Password: password,
      Timestamp: timestamp,
      TransactionType: 'CustomerPayBillOnline',
      Amount: amount,
      PartyA: formattedPhone,
      PartyB: BUSINESS_SHORT_CODE,
      PhoneNumber: formattedPhone,
      CallBackURL: `${process.env.NEXT_PUBLIC_APP_URL || 'https://example.com'}/api/mpesa/callback`,
      AccountReference: accountReference,
      TransactionDesc: transactionDesc,
    }),
  });

  if (!response.ok) {
    const errorBody = await response.text();
    throw new Error(`STK Push failed: ${response.status} - ${errorBody}`);
  }

  return response.json();
}

/**
 * Query STK Push transaction status
 */
export async function querySTKPush(
  checkoutRequestID: string
): Promise<STKQueryResponse> {
  const timestamp = generateTimestamp();
  const password = generatePassword(timestamp);

  const tokenData = await getAccessToken();

  const response = await fetch(`${BASE_URL}/mpesa/stkpushquery/v1/query`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${tokenData.access_token}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      BusinessShortCode: BUSINESS_SHORT_CODE,
      Password: password,
      Timestamp: timestamp,
      CheckoutRequestID: checkoutRequestID,
    }),
  });

  if (!response.ok) {
    const errorBody = await response.text();
    throw new Error(`STK Query failed: ${response.status} - ${errorBody}`);
  }

  return response.json();
}
