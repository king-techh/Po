/**
 * ToxicPay - Payment Gateway Engine v2
 * Platform-level Daraja integration + Demo mode
 * Toxic Tech Kenya is the aggregator - merchants just need API keys
 */

import { db } from '@/lib/db';
import { randomBytes, createHash } from 'crypto';

// ─── Configuration ───
const CALLBACK_MAX_ATTEMPTS = 5;
const CALLBACK_RETRY_INTERVALS = [5000, 15000, 60000, 300000, 900000];

// Daraja API URLs
const DARAJA_SANDBOX_URL = 'https://sandbox.safaricom.co.ke';
const DARAJA_PRODUCTION_URL = 'https://api.safaricom.co.ke';

// ─── Token Cache (in-memory, auto-refreshes) ───
interface TokenCache {
  token: string;
  expiresAt: number;
}

const tokenCache = new Map<string, TokenCache>();

// ─── Helpers ───
export function generateApiKey(): string {
  return `tpk_live_${randomBytes(24).toString('hex')}`;
}

export function generateApiSecret(): string {
  return `tps_${randomBytes(32).toString('hex')}`;
}

export function generateSandboxKey(): string {
  return `tpk_test_${randomBytes(24).toString('hex')}`;
}

export function generateTransactionRef(): string {
  const prefix = 'TPX';
  const timestamp = Date.now().toString(36).toUpperCase();
  const random = randomBytes(4).toString('hex').toUpperCase();
  return `${prefix}${timestamp}${random}`;
}

export function hashPassword(password: string): string {
  return createHash('sha256').update(password).digest('hex');
}

export function formatPhone(phone: string): string {
  let cleaned = phone.replace(/[\s\-+]/g, '');
  if (cleaned.startsWith('0')) {
    cleaned = '254' + cleaned.substring(1);
  } else if (cleaned.startsWith('7') || cleaned.startsWith('1')) {
    cleaned = '254' + cleaned;
  }
  return cleaned;
}

export function calculateServiceFee(amount: number, feePct: number = 1.5, minFee: number = 5): number {
  const fee = amount * (feePct / 100);
  return Math.max(fee, minFee);
}

// ─── Platform Settings ───
export async function getPlatformSettings() {
  let settings = await db.platformSettings.findFirst();
  if (!settings) {
    // Auto-create with defaults (sandbox Daraja test credentials)
    settings = await db.platformSettings.create({
      data: {
        businessName: 'TOXIC TECH PLUGGER',
        shortcode: '3200841',
        passkey: 'bfb279f9aa9bdbcf158e97dd71a467cd2e0c893059b10f78e6b72ada1ed2c919',
        environment: 'sandbox',
        channelType: 'till',
        serviceFeePct: 1.5,
        minServiceFee: 5,
        isConfigured: false,
      },
    });
  }
  return settings;
}

export async function updatePlatformSettings(data: {
  businessName?: string;
  shortcode?: string;
  passkey?: string;
  consumerKey?: string;
  consumerSecret?: string;
  environment?: string;
  channelType?: string;
  callbackBase?: string;
  serviceFeePct?: number;
  minServiceFee?: number;
}) {
  let settings = await db.platformSettings.findFirst();
  if (!settings) {
    settings = await db.platformSettings.create({
      data: {
        ...data,
        isConfigured: !!(data.consumerKey && data.consumerSecret),
      },
    });
  } else {
    await db.platformSettings.update({
      where: { id: settings.id },
      data: {
        ...data,
        isConfigured: !!(data.consumerKey ?? settings.consumerKey) && !!(data.consumerSecret ?? settings.consumerSecret),
      },
    });
    settings = (await db.platformSettings.findFirst())!;
  }
  return settings;
}

// ─── Daraja API Integration ───

function generateDarajaPassword(shortcode: string, passkey: string, timestamp: string): string {
  const raw = `${shortcode}${passkey}${timestamp}`;
  return Buffer.from(raw).toString('base64');
}

function generateDarajaTimestamp(): string {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  const hour = String(now.getHours()).padStart(2, '0');
  const minute = String(now.getMinutes()).padStart(2, '0');
  const second = String(now.getSeconds()).padStart(2, '0');
  return `${year}${month}${day}${hour}${minute}${second}`;
}

async function getDarajaAccessToken(
  consumerKey: string,
  consumerSecret: string,
  isSandbox: boolean
): Promise<string> {
  const cacheKey = `${consumerKey}:${isSandbox}`;
  const cached = tokenCache.get(cacheKey);
  if (cached && cached.expiresAt > Date.now()) {
    return cached.token;
  }

  const baseUrl = isSandbox ? DARAJA_SANDBOX_URL : DARAJA_PRODUCTION_URL;
  const auth = Buffer.from(`${consumerKey}:${consumerSecret}`).toString('base64');

  console.log(`🔑 Fetching Daraja access token (${isSandbox ? 'sandbox' : 'production'})...`);

  const response = await fetch(
    `${baseUrl}/oauth/v1/generate?grant_type=client_credentials`,
    {
      method: 'GET',
      headers: { Authorization: `Basic ${auth}` },
    }
  );

  if (!response.ok) {
    const errorText = await response.text();
    console.error(`❌ Daraja OAuth failed: ${response.status}`, errorText);
    throw new Error(
      `Daraja authentication failed (${response.status}). Check your Consumer Key/Secret in Platform Settings.`
    );
  }

  const data = await response.json();
  const token = data.access_token;
  const expiresIn = parseInt(data.expires_in || '3600');

  tokenCache.set(cacheKey, {
    token,
    expiresAt: Date.now() + (expiresIn - 300) * 1000,
  });

  console.log(`✅ Daraja access token obtained`);
  return token;
}

async function callDarajaSTKPush(
  accessToken: string,
  params: {
    BusinessShortCode: string;
    Password: string;
    Timestamp: string;
    TransactionType: string;
    Amount: number;
    PartyA: string;
    PartyB: string;
    PhoneNumber: string;
    CallBackURL: string;
    AccountReference: string;
    TransactionDesc: string;
  },
  isSandbox: boolean
): Promise<any> {
  const baseUrl = isSandbox ? DARAJA_SANDBOX_URL : DARAJA_PRODUCTION_URL;

  console.log(`📱 Calling Daraja STK Push API...`);
  console.log(`   Phone: ${params.PartyA}, Amount: ${params.Amount}, Shortcode: ${params.BusinessShortCode}`);

  const response = await fetch(`${baseUrl}/mpesa/stkpush/v1/processrequest`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(params),
  });

  const data = await response.json();

  if (!response.ok) {
    console.error(`❌ Daraja STK Push error:`, JSON.stringify(data));
    throw new Error(
      data.errorMessage || data.errorCode ||
      `Daraja STK Push failed (${response.status}). Check your shortcode and passkey.`
    );
  }

  console.log(`✅ Daraja STK Push response:`, JSON.stringify(data));
  return data;
}

async function callDarajaSTKQuery(
  accessToken: string,
  params: {
    BusinessShortCode: string;
    Password: string;
    Timestamp: string;
    CheckoutRequestID: string;
  },
  isSandbox: boolean
): Promise<any> {
  const baseUrl = isSandbox ? DARAJA_SANDBOX_URL : DARAJA_PRODUCTION_URL;

  const response = await fetch(`${baseUrl}/mpesa/stkpushquery/v1/query`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(params),
  });

  return response.json();
}

// ─── Authentication ───
export async function authenticateApiKey(key: string): Promise<{ merchantId: string; environment: string } | null> {
  const apiKey = await db.apiKey.findFirst({
    where: { key, active: true, revokedAt: null },
    select: { id: true, merchantId: true, environment: true },
  });

  if (apiKey) {
    db.apiKey.update({
      where: { id: apiKey.id },
      data: { lastUsedAt: new Date() },
    }).catch(() => {});
  }

  return apiKey ? { merchantId: apiKey.merchantId, environment: apiKey.environment } : null;
}

// ─── STK Push Engine ───
export interface STKInitiateParams {
  phone: string;
  amount: number;
  externalReference?: string;
  callbackUrl?: string;
  customerName?: string;
}

export interface STKInitiateResult {
  success: boolean;
  status: string;
  message: string;
  transactionId: string;
  checkoutRequestId: string;
  merchantRequestId: string;
  channelType: string;
  serviceFee: number;
  isDemo: boolean;
  routingInfo: {
    partyB: string;
    transactionType: string;
    description: string;
  };
  darajaResponse?: any;
}

export async function initiateSTKPush(
  merchantId: string,
  params: STKInitiateParams,
  isSandbox: boolean = false
): Promise<STKInitiateResult> {
  const { phone, amount, externalReference, callbackUrl } = params;
  const formattedPhone = formatPhone(phone);

  // 1. Validate merchant
  const merchant = await db.merchant.findUnique({ where: { id: merchantId } });
  if (!merchant || !merchant.active) {
    throw new Error('Merchant account not found or inactive');
  }

  // 2. Get platform settings
  const platform = await getPlatformSettings();

  // 3. Check if we should use demo mode or real Daraja
  const useRealDaraja = platform.isConfigured && platform.consumerKey && platform.consumerSecret;

  // 4. Calculate service fee
  const serviceFee = isSandbox ? 0 : calculateServiceFee(amount, platform.serviceFeePct, platform.minServiceFee);

  // 5. Check service wallet balance (skip for sandbox/demo)
  if (!isSandbox && merchant.serviceWallet < serviceFee) {
    throw new Error('Insufficient service wallet balance. Please top up your wallet.');
  }

  // Determine channel type and transaction type
  const isTill = (platform.channelType || 'paybill') === 'till';
  const transactionType = isTill ? 'CustomerBuyGoodsOnline' : 'CustomerPayBillOnline';
  const channelLabel = isTill ? 'till' : 'paybill';

  // ─── DEMO MODE (No Daraja credentials configured) ───
  if (!useRealDaraja) {
    const checkoutRequestId = `demo_${Date.now()}_${randomBytes(4).toString('hex')}`;
    const merchantRequestId = `demo_mrq_${Date.now()}`;

    const transaction = await db.transaction.create({
      data: {
        merchantId,
        merchantRequestId,
        checkoutRequestId,
        externalReference: externalReference || generateTransactionRef(),
        transactionType: 'c2b',
        amount,
        phone: formattedPhone,
        accountReference: isTill ? platform.shortcode : phone.replace(/\D/g, ''),
        status: 'initiated',
        serviceFee: 0,
        channelType: channelLabel,
        callbackUrl: callbackUrl || merchant.callbackUrl,
        isDemo: true,
        mpesaResultCode: '0',
      },
    });

    await db.activityLog.create({
      data: {
        merchantId,
        action: 'stk_initiated_demo',
        details: `DEMO STK Push sent to ${formattedPhone} for KES ${amount}. Add Daraja credentials in Platform Settings for real M-Pesa prompts.`,
      },
    });

    return {
      success: true,
      status: 'INITIATED',
      message: 'STK Push initiated in DEMO mode. The customer will see a simulated M-Pesa prompt. Add Daraja credentials in Settings for real prompts on the phone.',
      transactionId: transaction.id,
      checkoutRequestId,
      merchantRequestId,
      channelType: channelLabel,
      serviceFee: 0,
      isDemo: true,
      routingInfo: {
        partyB: platform.shortcode,
        transactionType,
        description: isTill
          ? `Till ${platform.shortcode} (DEMO)`
          : `Paybill ${platform.shortcode}, Account: ${phone.replace(/\D/g, '')} (DEMO)`,
      },
    };
  }

  // ─── REAL DARAJA MODE ───
  const isSandboxEnv = platform.environment === 'sandbox';

  // In sandbox mode, override with test shortcode/passkey (Daraja sandbox only supports 174379)
  // In production mode, use the configured Till/Paybill number
  const effectiveShortcode = isSandboxEnv ? '174379' : platform.shortcode;
  const effectivePasskey = isSandboxEnv
    ? 'bfb279f9aa9bdbcf158e97dd71a467cd2e0c893059b10f78e6b72ada1ed2c919'
    : platform.passkey;
  // Use CustomerBuyGoodsOnline for till in both sandbox and production
  const effectiveTransactionType = isSandboxEnv
    ? (isTill ? 'CustomerBuyGoodsOnline' : 'CustomerPayBillOnline')
    : transactionType;
  const effectiveChannelLabel = isSandboxEnv ? channelLabel : channelLabel;

  const timestamp = generateDarajaTimestamp();
  const password = generateDarajaPassword(effectiveShortcode, effectivePasskey, timestamp);
  const callBackURL = callbackUrl || merchant.callbackUrl || (platform.callbackBase
    ? `${platform.callbackBase}/api/v1/callback`
    : '');

  // For Till: AccountReference = Till number, PartyB = Till number
  // For Paybill: AccountReference = phone/account, PartyB = Paybill number
  const accountRef = isTill && !isSandboxEnv ? effectiveShortcode : phone.replace(/\D/g, '');

  // Get Daraja access token
  let accessToken: string;
  try {
    accessToken = await getDarajaAccessToken(
      platform.consumerKey!,
      platform.consumerSecret!,
      isSandboxEnv
    );
  } catch (error) {
    const msg = error instanceof Error ? error.message : 'Failed to authenticate with Daraja';
    throw new Error(msg);
  }

  // Call Daraja STK Push API
  let darajaResponse: any;
  try {
    darajaResponse = await callDarajaSTKPush(accessToken, {
      BusinessShortCode: effectiveShortcode,
      Password: password,
      Timestamp: timestamp,
      TransactionType: effectiveTransactionType,
      Amount: Math.round(amount),
      PartyA: formattedPhone,
      PartyB: effectiveShortcode,
      PhoneNumber: formattedPhone,
      CallBackURL: callBackURL,
      AccountReference: accountRef,
      TransactionDesc: `Payment to ${platform.businessName || 'TOXIC TECH PLUGGER'}`,
    }, isSandboxEnv);
  } catch (error) {
    const msg = error instanceof Error ? error.message : 'Daraja STK Push failed';
    throw new Error(msg);
  }

  const checkoutRequestId = darajaResponse.CheckoutRequestID || generateTransactionRef();
  const merchantRequestId = darajaResponse.MerchantRequestID || generateTransactionRef();
  const responseCode = darajaResponse.ResponseCode;

  if (responseCode !== '0') {
    throw new Error(
      darajaResponse.ResponseDescription ||
      darajaResponse.errorMessage ||
      'STK Push was rejected by Safaricom. Check your shortcode and passkey.'
    );
  }

  // Create transaction record
  const transaction = await db.transaction.create({
    data: {
      merchantId,
      merchantRequestId,
      checkoutRequestId,
      externalReference: externalReference || generateTransactionRef(),
      transactionType: 'c2b',
      amount,
      phone: formattedPhone,
      accountReference: accountRef,
      status: 'initiated',
      serviceFee,
      channelType: effectiveChannelLabel,
      callbackUrl: callBackURL,
      mpesaResultCode: responseCode,
      isDemo: false,
    },
  });

  // Deduct service fee
  if (!isSandbox && serviceFee > 0) {
    await db.merchant.update({
      where: { id: merchantId },
      data: { serviceWallet: { decrement: serviceFee } },
    });
  }

  await db.activityLog.create({
    data: {
      merchantId,
      action: 'stk_initiated',
      details: `STK Push sent to ${formattedPhone} for KES ${amount} via Daraja (${isSandboxEnv ? 'sandbox' : 'production'})`,
    },
  });

  return {
    success: true,
    status: 'INITIATED',
    message: isSandboxEnv
      ? 'STK Push sent via Daraja Sandbox! Check the test phone for the M-Pesa prompt.'
      : 'STK Push sent successfully! The customer will receive an M-Pesa prompt on their phone.',
    transactionId: transaction.id,
    checkoutRequestId,
    merchantRequestId,
    channelType: effectiveChannelLabel,
    serviceFee,
    isDemo: false,
    routingInfo: {
      partyB: effectiveShortcode,
      transactionType: effectiveTransactionType,
      description: isSandboxEnv
        ? `Sandbox test (174379). Production will use ${isTill ? 'Till' : 'Paybill'} ${platform.shortcode}`
        : isTill
          ? `Till ${platform.shortcode} - ${platform.businessName || merchant.businessName}`
          : `Paybill ${platform.shortcode}, Account: ${phone.replace(/\D/g, '')}`,
    },
  };
}

// ─── Demo Mode: Complete Transaction ───
export async function completeDemoTransaction(
  transactionId: string,
  success: boolean
): Promise<void> {
  const transaction = await db.transaction.findUnique({
    where: { id: transactionId },
  });

  if (!transaction || !transaction.isDemo) {
    throw new Error('Demo transaction not found');
  }

  const status = success ? 'completed' : 'failed';
  const receipt = success ? `DHK${randomBytes(4).toString('hex').toUpperCase()}` : null;

  await db.transaction.update({
    where: { id: transactionId },
    data: {
      status,
      mpesaReceipt: receipt,
      mpesaResultCode: success ? '0' : '1032',
      mpesaResultDesc: success ? 'The service request is processed successfully.' : 'Request cancelled by user',
      completedAt: new Date(),
    },
  });

  await db.activityLog.create({
    data: {
      merchantId: transaction.merchantId,
      action: success ? 'demo_payment_completed' : 'demo_payment_failed',
      details: `DEMO: Transaction ${transactionId}: KES ${transaction.amount} - ${status}${receipt ? ` Receipt: ${receipt}` : ''}`,
    },
  });

  // Dispatch webhook if callback URL exists (non-blocking, don't crash on failure)
  if (transaction.callbackUrl) {
    try {
      await dispatchWebhook(
        { ...transaction, status, mpesaReceipt: receipt, mpesaResultCode: success ? '0' : '1032' },
        transaction.callbackUrl
      );
    } catch (webhookError) {
      console.error('Webhook dispatch failed (non-fatal):', webhookError);
    }
  }
}

// ─── STK Query ───
export async function queryTransaction(
  merchantId: string,
  checkoutRequestId: string,
  isSandbox: boolean = false
): Promise<{
  status: string;
  resultCode: string;
  resultDesc: string;
  mpesaReceipt?: string;
  isDemo?: boolean;
}> {
  const transaction = await db.transaction.findFirst({
    where: { checkoutRequestId, merchantId },
  });

  if (!transaction) {
    throw new Error('Transaction not found');
  }

  // Demo mode: just return DB status
  if (transaction.isDemo) {
    return {
      status: transaction.status.toUpperCase(),
      resultCode: transaction.mpesaResultCode || '',
      resultDesc: transaction.mpesaResultDesc || '',
      mpesaReceipt: transaction.mpesaReceipt || undefined,
      isDemo: true,
    };
  }

  // Real Daraja mode
  const platform = await getPlatformSettings();
  if (!platform.isConfigured || !platform.consumerKey || !platform.consumerSecret) {
    return {
      status: transaction.status.toUpperCase(),
      resultCode: transaction.mpesaResultCode || '',
      resultDesc: transaction.mpesaResultDesc || '',
    };
  }

  try {
    const isSandboxEnv = platform.environment === 'sandbox';
    // In sandbox, use test shortcode for query too
    const queryShortcode = isSandboxEnv ? '174379' : platform.shortcode;
    const queryPasskey = isSandboxEnv
      ? 'bfb279f9aa9bdbcf158e97dd71a467cd2e0c893059b10f78e6b72ada1ed2c919'
      : platform.passkey;

    const accessToken = await getDarajaAccessToken(
      platform.consumerKey,
      platform.consumerSecret,
      isSandboxEnv
    );

    const timestamp = generateDarajaTimestamp();
    const password = generateDarajaPassword(queryShortcode, queryPasskey, timestamp);

    const result = await callDarajaSTKQuery(accessToken, {
      BusinessShortCode: queryShortcode,
      Password: password,
      Timestamp: timestamp,
      CheckoutRequestID: checkoutRequestId,
    }, isSandboxEnv);

    const resultCode = result.ResultCode;
    const resultDesc = result.ResultDesc || '';

    if (resultCode === '0') {
      await completeTransaction(transaction.id, true, undefined, '0', resultDesc, JSON.stringify(result));
      return { status: 'COMPLETED', resultCode: '0', resultDesc };
    } else if (resultCode === '1032' || resultCode === '1037' || resultCode === '1001') {
      await completeTransaction(transaction.id, false, undefined, String(resultCode), resultDesc, JSON.stringify(result));
      return { status: 'FAILED', resultCode: String(resultCode), resultDesc };
    }

    return { status: 'PENDING', resultCode: String(resultCode), resultDesc };
  } catch {
    return {
      status: transaction.status.toUpperCase(),
      resultCode: transaction.mpesaResultCode || '',
      resultDesc: transaction.mpesaResultDesc || '',
    };
  }
}

// ─── Transaction Completion (Callback Processor) ───
export async function completeTransaction(
  transactionId: string,
  success: boolean,
  mpesaReceipt?: string,
  resultCode?: string,
  resultDesc?: string,
  rawResult?: string
): Promise<void> {
  const transaction = await db.transaction.findUnique({
    where: { id: transactionId },
  });

  if (!transaction) return;

  const status = success ? 'completed' : 'failed';

  await db.transaction.update({
    where: { id: transactionId },
    data: {
      status,
      mpesaReceipt: mpesaReceipt || null,
      mpesaResultCode: resultCode || null,
      mpesaResultDesc: resultDesc || null,
      mpesaRawResult: rawResult || null,
      completedAt: new Date(),
    },
  });

  if (!success) {
    await db.merchant.update({
      where: { id: transaction.merchantId },
      data: { serviceWallet: { increment: transaction.serviceFee } },
    });
  }

  await db.activityLog.create({
    data: {
      merchantId: transaction.merchantId,
      action: success ? 'payment_completed' : 'payment_failed',
      details: `Transaction ${transactionId}: KES ${transaction.amount} - ${status}`,
    },
  });

  const callbackUrl = transaction.callbackUrl;
  if (callbackUrl) {
    try {
      await dispatchWebhook({ ...transaction, status, mpesaReceipt, mpesaResultCode: resultCode, mpesaResultDesc: resultDesc }, callbackUrl);
    } catch (webhookError) {
      console.error('Webhook dispatch failed (non-fatal):', webhookError);
    }
  }
}

// ─── Webhook Dispatcher ───
export async function dispatchWebhook(transaction: any, url: string): Promise<void> {
  const payload = {
    transaction_id: transaction.id,
    status: transaction.status.toUpperCase(),
    amount: transaction.amount,
    phone: transaction.phone,
    mpesa_receipt: transaction.mpesaReceipt,
    external_reference: transaction.externalReference,
    account_reference: transaction.accountReference,
    service_fee: transaction.serviceFee,
    channel_type: transaction.channelType,
    transaction_type: transaction.transactionType,
    mpesa_result_code: transaction.mpesaResultCode,
    mpesa_result_desc: transaction.mpesaResultDesc,
    completed_at: transaction.completedAt || new Date(),
    created_at: transaction.createdAt,
  };

  const delivery = await db.webhookDelivery.create({
    data: {
      merchantId: transaction.merchantId,
      transactionId: transaction.id,
      url,
      payload: JSON.stringify(payload),
      maxAttempts: CALLBACK_MAX_ATTEMPTS,
      nextRetryAt: new Date(),
    },
  });

  await attemptWebhookDelivery(delivery.id);
}

export async function attemptWebhookDelivery(deliveryId: string): Promise<boolean> {
  const delivery = await db.webhookDelivery.findUnique({ where: { id: deliveryId } });
  if (!delivery) return false;

  try {
    const response = await fetch(delivery.url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'User-Agent': 'TOXICPAY-CALLBACK/1.0',
      },
      body: delivery.payload,
      signal: AbortSignal.timeout(30000),
    });

    const responseBody = await response.text().catch(() => '');
    const success = response.status >= 200 && response.status < 300;

    await db.webhookDelivery.update({
      where: { id: deliveryId },
      data: {
        responseStatus: response.status,
        responseBody: responseBody.slice(0, 1000),
        success,
        attempts: { increment: 1 },
        deliveredAt: success ? new Date() : undefined,
        nextRetryAt: success ? undefined : getNextRetryDate(delivery.attempts + 1),
      },
    });

    if (success) {
      await db.transaction.update({
        where: { id: delivery.transactionId },
        data: { callbackDelivered: true, callbackAttempts: { increment: 1 } },
      });
    }

    return success;
  } catch (error) {
    await db.webhookDelivery.update({
      where: { id: deliveryId },
      data: {
        attempts: { increment: 1 },
        responseBody: error instanceof Error ? error.message : 'Unknown error',
        nextRetryAt: getNextRetryDate(delivery.attempts + 1),
      },
    });
    return false;
  }
}

function getNextRetryDate(attempt: number): Date {
  const intervals = CALLBACK_RETRY_INTERVALS;
  const delay = intervals[Math.min(attempt - 1, intervals.length - 1)] || 900000;
  return new Date(Date.now() + delay);
}

// ─── Dashboard Stats ───
export async function getMerchantDashboard(merchantId: string) {
  const [transactions, todayTx, completedTx, pendingTx, failedTx, recentActivity] = await Promise.all([
    db.transaction.findMany({ where: { merchantId } }),
    db.transaction.findMany({
      where: { merchantId, createdAt: { gte: new Date(new Date().setHours(0, 0, 0, 0)) } },
    }),
    db.transaction.count({ where: { merchantId, status: 'completed' } }),
    db.transaction.count({ where: { merchantId, status: { in: ['pending', 'initiated'] } } }),
    db.transaction.count({ where: { merchantId, status: 'failed' } }),
    db.activityLog.findMany({
      where: { merchantId },
      orderBy: { createdAt: 'desc' },
      take: 10,
    }),
  ]);

  const totalVolume = transactions.reduce((sum, t) => sum + (t.status === 'completed' ? t.amount : 0), 0);
  const todayVolume = todayTx.reduce((sum, t) => sum + (t.status === 'completed' ? t.amount : 0), 0);
  const totalFees = transactions.reduce((sum, t) => sum + (t.status === 'completed' ? t.serviceFee : 0), 0);

  return {
    totalTransactions: transactions.length,
    totalVolume,
    todayTransactions: todayTx.length,
    todayVolume,
    completedCount: completedTx,
    pendingCount: pendingTx,
    failedCount: failedTx,
    totalFees,
    recentActivity,
  };
}
