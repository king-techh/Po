module.exports=[18482,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_platform_settings_route_actions_e1e9e735.js.map