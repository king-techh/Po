module.exports=[31961,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_service-status_route_actions_51d6bf76.js.map