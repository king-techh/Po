module.exports=[9530,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_stk_demo-complete_route_actions_c84e9f3a.js.map