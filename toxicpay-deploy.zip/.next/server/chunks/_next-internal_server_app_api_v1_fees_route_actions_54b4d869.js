module.exports=[30255,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_fees_route_actions_54b4d869.js.map