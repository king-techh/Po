module.exports=[67244,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_stk_query_route_actions_08821670.js.map