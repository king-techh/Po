module.exports=[25974,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_stk_initiate_route_actions_635ac9ae.js.map