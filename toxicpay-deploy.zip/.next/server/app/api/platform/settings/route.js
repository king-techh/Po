var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/platform/settings/route.js")
R.c("server/chunks/[root-of-the-server]__6679cd0d._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_platform_settings_route_actions_e1e9e735.js")
R.m(18692)
module.exports=R.m(18692).exports
