var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/merchant/api-keys/route.js")
R.c("server/chunks/[root-of-the-server]__76766e2b._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_merchant_api-keys_route_actions_5d283f9c.js")
R.m(65939)
module.exports=R.m(65939).exports
