var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/callback/route.js")
R.c("server/chunks/[root-of-the-server]__6edf497b._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_callback_route_actions_2ea8a588.js")
R.m(34582)
module.exports=R.m(34582).exports
