var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/fees/route.js")
R.c("server/chunks/[root-of-the-server]__caf99454._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_fees_route_actions_54b4d869.js")
R.m(31629)
module.exports=R.m(31629).exports
