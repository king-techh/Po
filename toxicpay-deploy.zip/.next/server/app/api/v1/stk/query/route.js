var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/stk/query/route.js")
R.c("server/chunks/[root-of-the-server]__914b7f5c._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_stk_query_route_actions_08821670.js")
R.m(25647)
module.exports=R.m(25647).exports
