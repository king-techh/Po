var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/stk/initiate/route.js")
R.c("server/chunks/[root-of-the-server]__140a5120._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_stk_initiate_route_actions_635ac9ae.js")
R.m(92518)
module.exports=R.m(92518).exports
