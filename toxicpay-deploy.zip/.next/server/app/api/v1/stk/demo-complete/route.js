var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/stk/demo-complete/route.js")
R.c("server/chunks/[root-of-the-server]__d65388d6._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_stk_demo-complete_route_actions_c84e9f3a.js")
R.m(60329)
module.exports=R.m(60329).exports
