var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/transactions/route.js")
R.c("server/chunks/[root-of-the-server]__be990418._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_transactions_route_actions_4643174e.js")
R.m(54930)
module.exports=R.m(54930).exports
