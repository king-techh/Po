var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/service-status/route.js")
R.c("server/chunks/[root-of-the-server]__d5257635._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_service-status_route_actions_51d6bf76.js")
R.m(28612)
module.exports=R.m(28612).exports
