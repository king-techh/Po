#!/usr/bin/env node

/**
 * ToxicPay - Production Entry Point
 * Toxic Tech Kenya - M-Pesa Payment Gateway
 *
 * This is the main entry point for the ToxicPay application.
 * It sets up the database, generates the Prisma client, and starts the Next.js server.
 */

const { execSync, spawn } = require('child_process');
const path = require('path');

const PORT = process.env.PORT || 3000;
const HOST = process.env.HOSTNAME || '0.0.0.0';

console.log('');
console.log('═══════════════════════════════════════════════');
console.log('  TOXICPAY - Toxic Tech Kenya');
console.log('  M-Pesa Payment Gateway');
console.log('═══════════════════════════════════════════════');
console.log('');

// Step 1: Generate Prisma client
try {
  console.log('[setup] Generating Prisma client...');
  execSync('npx prisma generate --no-hints', {
    cwd: __dirname,
    stdio: 'pipe',
    timeout: 60000,
  });
  console.log('[setup] Prisma client ready');
} catch (e) {
  console.log('[setup] Prisma generate skipped (may already exist)');
}

// Step 2: Push database schema
try {
  console.log('[setup] Syncing database schema...');
  execSync('npx prisma db push --accept-data-loss', {
    cwd: __dirname,
    stdio: 'pipe',
    timeout: 30000,
  });
  console.log('[setup] Database schema synced');
} catch (e) {
  console.log('[setup] DB push skipped (may already be synced)');
}

// Step 3: Start Next.js server
console.log(`[server] Starting ToxicPay on ${HOST}:${PORT}...`);
console.log('');

const server = spawn('node', ['node_modules/next/dist/bin/next', 'start', '-p', String(PORT), '-H', HOST], {
  cwd: __dirname,
  stdio: 'inherit',
  env: {
    ...process.env,
    PORT,
    HOSTNAME: HOST,
  },
});

server.on('error', (err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});

server.on('exit', (code) => {
  console.log(`Server exited with code ${code}`);
  process.exit(code || 0);
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('Shutting down...');
  server.kill('SIGTERM');
});

process.on('SIGINT', () => {
  console.log('Shutting down...');
  server.kill('SIGINT');
});
