import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // output: "standalone",  // Not needed - we use next start
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
};

export default nextConfig;
